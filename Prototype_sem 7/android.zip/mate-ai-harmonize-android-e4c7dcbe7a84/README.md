
**Pre-Req:**

Android Studio

**Steps:**

1. Clone this project
2. Open this project in Android Studio
3. Android studio will give all the suggestions (Adding sdk, doing gradle setup)
4. Once all the setup and gradle build is done. Go to Run option in Studio and press run as .
5. If you find the error "Failed to install the following Android SDK packages as some licences have not been accepted." update the sdk tools of the sdk library which is present at the top right corner of the screen.

**Get the Apk**

https://drive.google.com/file/d/1DaqkkbO1BKomPb0u3KloFm6n90SpSkJl/view?usp=sharing