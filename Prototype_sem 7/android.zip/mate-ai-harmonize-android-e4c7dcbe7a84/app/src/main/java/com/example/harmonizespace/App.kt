package com.example.harmonizespace

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.lifecycle.MutableLiveData
import java.io.File

class App: Application() {
    companion object {
        lateinit var CHANNEL_1_ID: String
        lateinit var CHANNEL_2_ID: String
        lateinit var currentFile: MutableLiveData<File>
    }

    override fun onCreate() {
        super.onCreate()
        CHANNEL_1_ID = "channel 1"
        CHANNEL_2_ID = "channel 2"
        currentFile = MutableLiveData()
        createNotifChannels()
    }
    private fun createNotifChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel1 = NotificationChannel(
                CHANNEL_1_ID, "Channel 1", NotificationManager.IMPORTANCE_HIGH
            )
            channel1.description = "This is channel 1"
            val channel2 = NotificationChannel(
                CHANNEL_2_ID, "Channel 2", NotificationManager.IMPORTANCE_HIGH
            )
            channel2.description = "This is channel 2"
            val notificationManager = getSystemService(
                NotificationManager::class.java
            )
            notificationManager.createNotificationChannel(channel1)
            notificationManager.createNotificationChannel(channel2)
        }
    }
}