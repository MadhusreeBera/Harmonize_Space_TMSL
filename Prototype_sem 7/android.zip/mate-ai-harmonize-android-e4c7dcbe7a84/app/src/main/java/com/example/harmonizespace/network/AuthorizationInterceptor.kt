package com.example.harmonizespace.network

import android.content.Context
import com.example.harmonizespace.R
import okhttp3.Interceptor
import okhttp3.Response

class AuthorizationInterceptor(val context: Context): Interceptor {
    val sharedPreferences = context.getSharedPreferences(context.getString(R.string.harmonizeSpace), Context.MODE_PRIVATE);
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .addHeader("Authorization", sharedPreferences.getString("TOKEN",null) ?: "")
            .build()

        return chain.proceed(request)
    }
}