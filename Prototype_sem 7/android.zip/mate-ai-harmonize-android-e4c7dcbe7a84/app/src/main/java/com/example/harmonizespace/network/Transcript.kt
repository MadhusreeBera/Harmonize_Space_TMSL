package com.example.harmonizespace.network

class Transcript(
    val file: String? = null,
    val text: String? = null
)