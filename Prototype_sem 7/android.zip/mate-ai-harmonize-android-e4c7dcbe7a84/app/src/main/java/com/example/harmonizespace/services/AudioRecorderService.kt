package com.example.harmonizespace.services

import android.app.Activity
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.harmonizespace.App
import com.example.harmonizespace.ui.HomeActivity
import com.example.harmonizespace.ui.MainActivity
import java.io.File
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*
import timber.log.Timber
import kotlin.concurrent.thread


class AudioRecorderService : Service() {

    private var recorder: MediaRecorder? = null
    private lateinit var currAudioFile: File

    private lateinit var timerThread: Thread
    private var stopRecording = false

    private lateinit var recorderQueue: Queue<MediaRecorder>
    private lateinit var fileQueue: Queue<File>


    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        recorderQueue = LinkedList()
        fileQueue = LinkedList()

        for(i in 0..100) {
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(applicationContext)
            } else MediaRecorder()

            var recording = getNewFile()

            Timber.d("startService1: Saving rec at : ${recording.absolutePath}")

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.DEFAULT)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(recording.absolutePath)
                prepare()
            }

            recorderQueue.add(recorder)
            fileQueue.add(recording)
        }
        startForeground(SERVICE_ID, createNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return if (intent != null) {
            when (intent.action) {
                ACTION_START -> {
                    stopRecording = false
                    startCapturing()
                    Service.START_STICKY
                }
                ACTION_STOP -> {
                    stopRecording = true
                    Service.START_NOT_STICKY
                }
                else -> throw IllegalArgumentException("Unexpected action received: ${intent.action}")
            }
        } else {
            Service.START_NOT_STICKY
        }
    }

    private fun startCapturing()
    {
        recorder = recorderQueue.poll()
        currAudioFile = fileQueue.poll()!!
        recorder?.start()

        timerThread = thread(start = true) {
            while(!stopRecording && !recorderQueue.isEmpty()) {
                Thread.sleep(5L*1000)
                recorder?.stop();
                recorder?.reset();   // You can reuse the object by going back to setAudioSource() step
                recorder?.release()

                App.currentFile.postValue(currAudioFile)
//                startService1(i+1)
                recorder = recorderQueue.poll()
                currAudioFile = fileQueue.poll()!!

                try{
                recorder?.start()
                }
                catch (e: Exception){
                    Timber.e(e.message)
                    Timber.e(e.cause)
                }
            }
            if (recorder == null){
                Timber.d("Recorder not initialised, can't stop")
            }
            else {
                recorder?.stop();
                recorder?.reset();   // You can reuse the object by going back to setAudioSource() step
                recorder?.release(); // Now the object cannot be reused

                App.currentFile.postValue(currAudioFile)
                stopSelf()
            }
        }
    }

    private fun getNewFile(): File {
        val formatter = SimpleDateFormat("yyyy_MM_dd_hh_mm_ss", Locale.ENGLISH)
        val date = Date()
        val recDir = File(applicationContext.filesDir, "//Recordings")
        if (!recDir.exists()) recDir.mkdir()
        val recording = File(
            applicationContext.filesDir,
            "//Recordings//Rec_" + formatter.format(date) + ".webm"
        )
        if (!recording.exists()) {
            try {
                recording.createNewFile()
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
        return recording
    }

    private fun createNotification(): Notification{
        val activityIntent = Intent(this, HomeActivity::class.java)
        val contentIntent =
            PendingIntent.getActivity(this, 1, activityIntent, PendingIntent.FLAG_UPDATE_CURRENT)
        var notification: Notification? = null
        notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, App.CHANNEL_1_ID)
                .setContentTitle("Audio Record")
                .setContentText("Recording")
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .build()
        } else {
            Notification.Builder(this)
                .setCategory(Notification.CATEGORY_MESSAGE)
                .setContentTitle("Audio Record")
                .setContentText("Recording")
                .setPriority(Notification.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setVisibility(Notification.VISIBILITY_PUBLIC).build()
        }
        return notification
    }

    companion object {
        private const val TAG = "AudioRecorderService"
        private const val SERVICE_ID = 123
        private const val NOTIFICATION_CHANNEL_ID = "AudioCapture channel"

        const val ACTION_START = "AudioCaptureService:Start"
        const val ACTION_STOP = "AudioCaptureService:Stop"
        const val EXTRA_RESULT_DATA = "AudioCaptureService:Extra:ResultData"
    }
}