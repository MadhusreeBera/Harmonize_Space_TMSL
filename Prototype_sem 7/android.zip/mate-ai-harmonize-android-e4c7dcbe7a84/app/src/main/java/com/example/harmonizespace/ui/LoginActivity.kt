package com.example.harmonizespace.ui

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.apollographql.apollo.ApolloCall
import com.apollographql.apollo.ApolloClient
import com.apollographql.apollo.api.Response
import com.apollographql.apollo.exception.ApolloException
import com.example.apollographqlandroid.RefreshTokenMutation
import com.example.harmonizespace.R
import com.example.harmonizespace.databinding.ActivityLoginBinding
import java.util.*

import timber.log.Timber


class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        sharedPreferences = getSharedPreferences(getString(R.string.harmonizeSpace),
            Context.MODE_PRIVATE);
        editor = sharedPreferences.edit()


        binding.progressCard.visibility = View.VISIBLE

        val action: String? = intent?.action
        val data: Uri? = intent?.data
        val refeshToken = data?.getQueryParameter("token");

        getToken(refeshToken!!)

    }


    fun getToken(refreshToken: String){
        val apolloClient = ApolloClient.builder()
            .serverUrl("https://development.harmonize.space/graphql")
            .build()

        val authToken = RefreshTokenMutation(refreshToken)

        apolloClient
            .mutate(authToken)
            .enqueue(object: ApolloCall.Callback<RefreshTokenMutation.Data>() {
                override fun onResponse(response: Response<RefreshTokenMutation.Data>) {
                    Timber.d(response.toString());
                    val token = response.data?.refreshToken?.token
                    val uid = response.data?.refreshToken?.user?._id

                    editor.putString("TOKEN", token)
                    editor.putString("UID", uid)
                    editor.putLong("TOKEN_UPDATED_AT", Calendar.getInstance().timeInMillis)
                    editor.apply()
                    startActivity(Intent(this@LoginActivity, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                }

                override fun onFailure(e: ApolloException) {
                    Timber.e(e.message);
                }
            })
    }
}