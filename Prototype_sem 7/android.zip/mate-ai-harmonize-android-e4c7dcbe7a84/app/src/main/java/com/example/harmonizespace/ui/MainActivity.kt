package com.example.harmonizespace.ui

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import com.example.harmonizespace.R
import com.example.harmonizespace.databinding.ActivityMainBinding
import com.example.harmonizespace.ui.ui.OpenUrlListener
import java.util.*
import timber.log.Timber
import kotlin.math.abs
import androidx.browser.customtabs.CustomTabsIntent
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsClient

import android.content.ComponentName

import androidx.browser.customtabs.CustomTabsServiceConnection
import com.example.harmonizespace.ui.ui.customtab.WebviewFallback

import com.example.harmonizespace.ui.ui.customtab.CustomTabActivityHelper




class MainActivity : AppCompatActivity(), OpenUrlListener{

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var binding: ActivityMainBinding
    private val authUrl = "https://development.harmonize.space/auth/googleAuth?deviceId=uniques"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        sharedPreferences = getSharedPreferences(getString(R.string.harmonizeSpace),
            Context.MODE_PRIVATE);

        var isTokenValid = false
        val timeDiffForToken = abs(sharedPreferences.getLong("TOKEN_UPDATED_AT",0) - Calendar.getInstance().timeInMillis)
        if(timeDiffForToken >= 5L*3600*1000){
            isTokenValid = true
        }

        binding.btnSignIn.setOnClickListener {
            openWithCustomTabClient()
        }

        if(sharedPreferences.getString("TOKEN",null)!=null && !isTokenValid) {  //call other modules
            binding.btnSignIn.visibility = View.INVISIBLE
            startActivity(Intent(this, HomeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }
        else{
            //open server link for auth
//            binding.btnSignIn.visibility = View.VISIBLE
            val editor = sharedPreferences.edit()
            editor.clear()
            editor.apply()

            //openInWebView()
        }

    }

    fun openInWebView(){
        val webView = binding.loginWebView

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.userAgentString = "com.example.harmonizespace"

        webView.webViewClient = CustomWebViewClient(this)
        webView.loadUrl(authUrl)
    }
    private fun openWithCustomTabClient(){
        val builder = CustomTabsIntent.Builder()


        val colorInt: Int = getColor(R.color.dominant_blue_700) //shade of blue

        val defaultColors = CustomTabColorSchemeParams.Builder()
            .setToolbarColor(colorInt)
            .build()
        builder.setDefaultColorSchemeParams(defaultColors)

        val customTabsIntent = builder.build()

        CustomTabActivityHelper.openCustomTab(
            this, customTabsIntent, Uri.parse(authUrl), WebviewFallback()
        )

//        customTabsIntent.launchUrl(this, Uri.parse(authUrl))
    }

    fun opeWithDefaultBrowser(){
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(authUrl))
        startActivity(browserIntent)
    }

    class CustomWebViewClient(val openUrlListener: OpenUrlListener) : WebViewClient() {

        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            val url = request?.url.toString();
            if(url.contains("harmonize:"))
            {
                openUrlListener.openUrl(Uri.parse(url))
                return true;
            }
            view?.loadUrl(request?.url.toString())
            return true
        }
    }

    override fun openUrl(uri: Uri) {
        val browserIntent = Intent(Intent.ACTION_VIEW, uri)
        startActivity(browserIntent);
    }

}