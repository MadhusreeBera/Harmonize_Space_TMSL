package com.example.harmonizespace.ui.ui

import android.net.Uri

interface OpenUrlListener {
    fun openUrl(uri: Uri)
}