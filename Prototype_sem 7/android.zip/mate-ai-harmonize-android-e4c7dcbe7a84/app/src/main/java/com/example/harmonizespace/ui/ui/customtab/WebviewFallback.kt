package com.example.harmonizespace.ui.ui.customtab

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat.startActivity
import com.example.harmonizespace.ui.ui.customtab.CustomTabActivityHelper.CustomTabFallback


/**
 * A Fallback that opens a Webview when Custom Tabs is not available
 */
class WebviewFallback : CustomTabFallback {
    override fun openUri(activity: Activity?, uri: Uri?) {
        val browserIntent = Intent(Intent.ACTION_VIEW, uri)
        activity?.startActivity(browserIntent)
    }
}