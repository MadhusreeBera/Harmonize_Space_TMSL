package com.example.harmonizespace.ui.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.harmonizespace.R
import com.example.harmonizespace.databinding.ItemFolderBinding

class FoldersAdapter: ListAdapter<String, FoldersAdapter.FoldersVH>(DiffUtilItemCallback){

    object DiffUtilItemCallback : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem.compareTo(newItem)==0
        }

        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean {
            return oldItem.compareTo(newItem)==0
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoldersVH {
        val binding = ItemFolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return FoldersVH(binding)
    }

    override fun onBindViewHolder(holder: FoldersVH, position: Int) {

        holder.bind(getItem(position))
    }

    class FoldersVH(val binding: ItemFolderBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(name: String){
            binding.etFolderName.setText(name)
            binding.etFolderName.isFocusable = false
            binding.etFolderName.isClickable = false
            binding.etFolderName.isCursorVisible = false
            binding.etFolderName.isEnabled = false
        }
    }
}