package com.example.harmonizespace.ui.ui.dashboard

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.apollographql.apollo.ApolloCall
import com.apollographql.apollo.ApolloClient
import com.apollographql.apollo.api.Response
import com.apollographql.apollo.exception.ApolloException
import com.bumptech.glide.Glide
import com.example.apollographqlandroid.CreateFolerMutation
import com.example.apollographqlandroid.EnableDriveMutation
import com.example.apollographqlandroid.ProfileQuery
import com.example.harmonizespace.R
import com.example.harmonizespace.databinding.FragmentFoldersBinding
import com.example.harmonizespace.network.AuthorizationInterceptor
import com.example.harmonizespace.ui.HomeActivity
import com.example.harmonizespace.ui.ui.notifications.ProfileFragment
import com.example.harmonizespace.ui.ui.notifications.ProfileViewModel
import java.util.*
import okhttp3.OkHttpClient
import timber.log.Timber
import kotlin.collections.ArrayList
import android.view.inputmethod.EditorInfo
import android.widget.ProgressBar

import android.widget.TextView.OnEditorActionListener

class FoldersFragment : Fragment() {

    private lateinit var foldersViewModel: FoldersViewModel
    private lateinit var profileViewModel: ProfileViewModel

    private lateinit var sharedPreferences: SharedPreferences
    private var authToken: String? = null

    private var _binding: FragmentFoldersBinding? = null

    private lateinit var apolloClient: ApolloClient
    private lateinit var user: ProfileQuery.Profile

    private lateinit var foldersAdapter: FoldersAdapter

    private lateinit var progressDialog: AlertDialog

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        foldersViewModel = ViewModelProvider(this)[FoldersViewModel::class.java]
        profileViewModel = ViewModelProvider(this)[ProfileViewModel::class.java]

        _binding = FragmentFoldersBinding.inflate(inflater, container, false)
        val root: View = binding.root

        sharedPreferences = requireContext().getSharedPreferences(getString(R.string.harmonizeSpace),
            Context.MODE_PRIVATE);

        authToken = sharedPreferences.getString("TOKEN",null)

        initClient()
        return root
    }
    fun initListeners(){
        binding.fabAddFolder.setOnClickListener {
            if(user.isDriveEnabled!!)
                inputFolderName()
            else showEnableDriveConsentDialog()
        }
    }

    private fun showEnableDriveConsentDialog(){
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Enable Drive")
            .setMessage("Please enable your drive to create and maintain files inside the app.")
            .setPositiveButton("Enable", DialogInterface.OnClickListener { dialogInterface, i ->
                showProgressDialog()
                dialogInterface.dismiss()
                enableDrive()
            })
            .setNegativeButton("Ignore", DialogInterface.OnClickListener { dialogInterface, i ->
                dialogInterface.cancel()
            })
        val dialog = builder.create()
        dialog.setCanceledOnTouchOutside(false)
        dialog.show()
    }

    fun inputFolderName(){
        val dialogView: View = layoutInflater.inflate(R.layout.item_folder, null)
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setView(dialogView)
        val folderNameView = dialogView.findViewById<EditText>(R.id.et_folder_name)
        folderNameView.imeOptions = EditorInfo.IME_ACTION_DONE
        folderNameView.maxLines = 1

        folderNameView.hint = "Enter a name"
        builder.setOnDismissListener {
            Timber.d("Called")
            //call create folder
            val name = folderNameView.text.toString()
            if(name.isBlank() || name.isEmpty() || name == ""){
                Toast.makeText(
                    requireContext(),
                    "Empty Folder name rejected",
                    Toast.LENGTH_SHORT
                ).show()
            }
            else createFolder(name)
        }

        val dialog = builder.create()
        folderNameView.setOnEditorActionListener { v, actionId, event ->
            return@setOnEditorActionListener when (actionId) {
                EditorInfo.IME_ACTION_DONE -> {
                    dialog.dismiss()
                    true
                }
                else -> false
            }
        }
        if(dialog.window!=null)
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show()
    }

    override fun onStart() {
        super.onStart()
        initUser()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        foldersAdapter = FoldersAdapter()

        binding.rvFolders.adapter = foldersAdapter

        foldersViewModel.allFiles.observe(requireActivity(), Observer {

            val folders = ArrayList<String>()
            for (file in it.data!!){
                folders.add(file?.name!!)
            }
            foldersAdapter.submitList(folders)
            foldersAdapter.notifyDataSetChanged()
        })
    }

    fun createFolder(name: String?){
        val createFolder = CreateFolerMutation(name!!, user.root!!)

        apolloClient
            .mutate(createFolder)
            .enqueue(object: ApolloCall.Callback<CreateFolerMutation.Data>() {
                override fun onResponse(response: Response<CreateFolerMutation.Data>) {
                    Timber.d(response.toString());
                    //Toast.makeText(requireContext(), "Folder created", Toast.LENGTH_SHORT).show()
                    foldersViewModel.getAllFiles(apolloClient, user.root!!)
                }

                override fun onFailure(e: ApolloException) {
                    Timber.e(e.message);
                }
            })
    }

    fun showProgressDialog(){
        val dialogView: View = layoutInflater.inflate(R.layout.layout_progress_dialog, null)
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setView(dialogView)

        progressDialog = builder.create()

        progressDialog.show()
    }

    fun hideProgressDialog(success: Boolean){
        progressDialog.cancel()
        if(success)
            Toast.makeText(requireContext(), "Drive Enabled Successfully", Toast.LENGTH_LONG).show()
        else Toast.makeText(requireContext(), "Failed to enable drive", Toast.LENGTH_LONG).show()
    }

    fun enableDrive(){
        val enableDrive = EnableDriveMutation()

        apolloClient
            .mutate(enableDrive)
            .enqueue(object: ApolloCall.Callback<EnableDriveMutation.Data>() {
                override fun onResponse(response: Response<EnableDriveMutation.Data>) {
                    Timber.d(response.toString());

                    if(response.data?.enableDrive!=null) {
                        activity?.runOnUiThread {
                            hideProgressDialog(true)
                        }
                    }
                    else {
                        activity?.runOnUiThread {
                            hideProgressDialog(false)
                        }
                    }
                    //if(response.data?.enableDrive?.isDriveEnabled!!)
//                    Toast.makeText(requireContext(), "Drive Enabled", Toast.LENGTH_LONG).show()
                }

                override fun onFailure(e: ApolloException) {
                    Timber.e(e.message);
                    activity?.runOnUiThread {
                        hideProgressDialog(false)
                    }
                }
            })
    }

    fun initUser(){
         profileViewModel.getUser(apolloClient)

         profileViewModel.user.observe(requireActivity(), Observer {
             user = it;
//             if(!user.isDriveEnabled!!)
//             {
//                 enableDrive()
//             }
             if(!user.isDriveEnabled!!)
                showEnableDriveConsentDialog()
             initListeners()
             foldersViewModel.getAllFiles(apolloClient, user.root)
             //todo update recycler view here
         })
     }


    fun initClient(){
        apolloClient = ApolloClient.builder()
            .serverUrl("https://development.harmonize.space/graphql")
            .okHttpClient(
                OkHttpClient.Builder()
                    .addInterceptor(AuthorizationInterceptor(requireContext()))
                    .build()
            )
            .build()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}