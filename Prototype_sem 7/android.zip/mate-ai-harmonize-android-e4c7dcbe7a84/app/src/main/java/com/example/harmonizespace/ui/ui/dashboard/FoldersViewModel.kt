package com.example.harmonizespace.ui.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.apollographql.apollo.ApolloClient
import com.apollographql.apollo.api.Input
import com.apollographql.apollo.coroutines.await
import com.apollographql.apollo.exception.ApolloException
import com.example.apollographqlandroid.AllFilesQuery
import com.example.apollographqlandroid.ProfileQuery
import com.example.type.FileFilter
import com.example.type.FileType
import kotlinx.coroutines.launch
import timber.log.Timber

class FoldersViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is dashboard Fragment"
    }
    val text: LiveData<String> = _text

    private val _allFiles = MutableLiveData<AllFilesQuery.AllFiles>()
    val allFiles: LiveData<AllFilesQuery.AllFiles> = _allFiles


    fun getAllFiles(apolloClient: ApolloClient, parentId: String?){
        viewModelScope.launch {
            val response = try {
                val filter = FileFilter(Input.absent(), Input.fromNullable(FileType.FOLDER), Input.fromNullable(parentId))
                apolloClient.query(AllFilesQuery(filter, 1)).await()
            } catch (e: ApolloException) {
                // handle protocol errors
                Timber.e("Apollo Exception: $e")

                return@launch
            }

            val files = response.data?.allFiles
            if (files == null || response.hasErrors()) {
                // handle application errors
                return@launch
            }
            _allFiles.postValue(files!!)
        }
    }
}