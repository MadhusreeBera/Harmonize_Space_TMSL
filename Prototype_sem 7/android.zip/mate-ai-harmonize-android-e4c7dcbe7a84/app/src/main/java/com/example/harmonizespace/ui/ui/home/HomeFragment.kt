package com.example.harmonizespace.ui.ui.home

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startForegroundService
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.harmonizespace.App
import com.example.harmonizespace.R
import com.example.harmonizespace.databinding.FragmentHomeBinding
import com.example.harmonizespace.services.AudioCaptureService
import com.example.harmonizespace.services.AudioRecorderService
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import timber.log.Timber

import kotlin.collections.ArrayList
import kotlin.concurrent.thread
import kotlin.experimental.and


class HomeFragment : Fragment() {

    private lateinit var homeViewModel: HomeViewModel
    private var _binding: FragmentHomeBinding? = null

    private var recorder: MediaRecorder? = null

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    private lateinit var audioCaptureThread: Thread
    private var audioRecord: AudioRecord? = null

    private val REQUEST_CODE = 0
    private val REQUEST_CODE1 = 1

    private lateinit var mediaProjectionManager: MediaProjectionManager
    private var mediaProjection: MediaProjection? = null

    private var transcriptsAdapter: TranscriptAdapter? = null
    private var transcripts: ArrayList<String?>? = ArrayList()

    private var currAudioFile: File? = null
    private var nextAudioFile: File? = null

    private val NUM_SAMPLES_PER_READ = 1024
    private val BYTES_PER_SAMPLE = 2 // 2 bytes since we hardcoded the PCM 16-bit format
    private val BUFFER_SIZE_IN_BYTES = NUM_SAMPLES_PER_READ * BYTES_PER_SAMPLE


    private lateinit var timerThread: Thread
    private var stopRecording = false
    private lateinit var mContext: Context

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        mediaProjectionManager = requireActivity().applicationContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textHome
        homeViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })

        mContext = requireActivity().applicationContext

        return root
    }

    private fun getNewFile(): File{
        val formatter = SimpleDateFormat("yyyy_MM_dd_hh_mm_ss", Locale.ENGLISH)
        val date = Date()
        val recDir = File(requireContext().filesDir, "//Recordings")
        if (!recDir.exists()) recDir.mkdir()
        val recording = File(
            requireContext().filesDir,
            "//Recordings//Rec_" + formatter.format(date) + ".webm"
        )
        if (!recording.exists()) {
            try {
                recording.createNewFile()
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
        return recording
    }

    private fun ShortArray.toByteArray(): ByteArray {
        // Samples get translated into bytes following little-endianness:
        // least significant byte first and the most significant byte last
        val bytes = ByteArray(size * 2)
        for (i in 0 until size) {
            bytes[i * 2] = (this[i] and 0x00FF).toByte()
            bytes[i * 2 + 1] = (this[i].toInt() shr 8).toByte()
            this[i] = 0
        }
        return bytes
    }


    @RequiresApi(Build.VERSION_CODES.O)
    private fun startService1(i: Int)
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            recorder = MediaRecorder(mContext)
        }
        else recorder = MediaRecorder()


        val id = sharedPreferences.getInt("ID",2)
        //audioViewModel.insert(MediaStore.Audio(id, recording.absolutePath, ""))
        editor.putInt("ID",id+1)
        editor.apply()

        var recording = getNewFile()

        Timber.d("startService1: Saving rec at : ${recording.absolutePath}")

        if(recorder==null){
            Timber.d("Recorder not initialised")
            return
        }
        recorder?.apply {
            setAudioSource(MediaRecorder.AudioSource.DEFAULT)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(recording.absolutePath)
            prepare()
        }
        currAudioFile = recording

        recorder?.start()

        if(i==0) {
            val intent = Intent(requireContext(), AudioRecorderService::class.java)
            ContextCompat.startForegroundService(requireActivity(), intent)
        }
        timerThread = thread(start = true) {
            while(!stopRecording) {
                Thread.sleep(5L*1000)
                recorder?.stop();
                recorder?.reset();   // You can reuse the object by going back to setAudioSource() step
                recorder?.release()

                homeViewModel.getTranscripts(currAudioFile!!)
//                startService1(i+1)
                recording = getNewFile()
//                val recorder1 = recorder.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    recorder = MediaRecorder(mContext)
                }
                else recorder = MediaRecorder()
                recorder?.apply {
                    setAudioSource(MediaRecorder.AudioSource.DEFAULT)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setOutputFile(recording.absolutePath)
                    prepare()
                }
                currAudioFile = recording
//                recorder?.setOutputFile(recording)
//                recorder?.prepare()
                recorder?.start()
            }
        }
    }

    private fun isRecordAudioPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }


    private fun startCapturing() {
        if (!isRecordAudioPermissionGranted()) {
            checkAndRequestPermissions()
        } else {
            startMediaProjectionRequest()
        }
    }

    private fun stopCapturing() {
        requireActivity().stopService(Intent(requireContext(), AudioCaptureService::class.java))
    }
    private fun startMediaProjectionRequest() {
        // use applicationContext to avoid memory leak on Android 10.
        // see: https://partnerissuetracker.corp.google.com/issues/139732252
        mediaProjectionManager =
            requireActivity().applicationContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(
            mediaProjectionManager.createScreenCaptureIntent(),
            MEDIA_PROJECTION_REQUEST_CODE
        )
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == MEDIA_PROJECTION_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(
                    requireContext(),
                    "MediaProjection permission obtained. Foreground service will be started to capture audio.",
                    Toast.LENGTH_SHORT
                ).show()

                val audioCaptureIntent = Intent(requireContext(), AudioCaptureService::class.java).apply {
                    action = AudioCaptureService.ACTION_START
                    putExtra(AudioCaptureService.EXTRA_RESULT_DATA, data!!)
                }
                startForegroundService(requireContext(), audioCaptureIntent)

            } else {
                Toast.makeText(
                    requireContext(), "Request to obtain MediaProjection denied.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    companion object {
        private const val RECORD_AUDIO_PERMISSION_REQUEST_CODE = 42
        private const val MEDIA_PROJECTION_REQUEST_CODE = 13
    }
    private fun stopService1()
    {
        editor.putBoolean("RECORD_STARTED",false)
        editor.apply()

        if (recorder == null){
            Timber.d("Recorder not initialised, can't stop")
            return
        }

        recorder?.stop();
        recorder?.reset();   // You can reuse the object by going back to setAudioSource() step
        recorder?.release(); // Now the object cannot be reused
        val intent = Intent(requireContext(),AudioRecorderService::class.java)
        requireActivity().stopService(intent)
        homeViewModel.getTranscripts(currAudioFile!!)
        nextAudioFile = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        checkAndRequestPermissions()

        sharedPreferences = requireActivity().getSharedPreferences(
            getString(R.string.app_name), Context.MODE_PRIVATE)
        editor = sharedPreferences.edit()

        App.currentFile.observe(viewLifecycleOwner, Observer {
            homeViewModel.getTranscripts(it)
        })

        binding.fabStartRecording.setOnClickListener {
            if(!sharedPreferences.getBoolean("RECORD_STARTED",false)) {
//                stopRecording = false
                //startService1(0)
                editor.putBoolean("RECORD_STARTED",true)
                binding.fabStartRecording.setImageDrawable(ContextCompat.getDrawable(requireContext(), android.R.drawable.ic_media_pause))
                startCapturing()
//                val audioCaptureIntent = Intent(requireContext(), AudioRecorderService::class.java).apply {
//                    action = AudioRecorderService.ACTION_START
//                }
//                startForegroundService(requireContext(), audioCaptureIntent)
            }
            else {
//                stopRecording = true
//                stopService1()
                editor.putBoolean("RECORD_STARTED",false)
                binding.fabStartRecording.setImageDrawable(ContextCompat.getDrawable(requireContext(), android.R.drawable.ic_btn_speak_now))
                stopCapturing()
//                requireActivity().startService(Intent(requireContext(), AudioRecorderService::class.java).apply {
//                    action = AudioRecorderService.ACTION_STOP
//                })

            }
            editor.apply()
        }

        val testTransFilePath = "//Recordings//Rec_2021_12_31_12_19_36.mp3"
        var file = File(requireContext().filesDir, testTransFilePath)

        transcriptsAdapter = TranscriptAdapter()

        binding.rvGeneratedTexts.adapter = transcriptsAdapter
        transcriptsAdapter?.submitList(transcripts)

//        homeViewModel.getTranscripts(file)
        initListeners()

    }

    private fun initListeners(){
        homeViewModel.text.observe(viewLifecycleOwner, Observer {
            if(it!=null && !it.equals("")) {
                transcripts?.add(it)
                transcriptsAdapter?.submitList(transcripts)
                val pos = transcripts!!.indexOf(it)
                transcriptsAdapter?.notifyItemInserted(pos)
                binding.rvGeneratedTexts.smoothScrollToPosition(pos)
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun checkAndRequestPermissions()
    {
        var permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.PROCESS_OUTGOING_CALLS,Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_EXTERNAL_STORAGE)

        for(permission in permissions){
            if(ContextCompat.checkSelfPermission(requireContext(),permission)== PackageManager.PERMISSION_GRANTED){
            }
            else {
                requestPermissions(permissions,REQUEST_CODE)
                break
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Timber.d("onRequestPermissionsResult: All granted")
            } else {
                Timber.d("onRequestPermissionsResult: None granted")
            }
        }
    }
}