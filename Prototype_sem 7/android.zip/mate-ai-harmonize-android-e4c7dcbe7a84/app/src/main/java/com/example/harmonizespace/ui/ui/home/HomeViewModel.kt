package com.example.harmonizespace.ui.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.harmonizespace.network.ApiService
import com.example.harmonizespace.network.Transcript
import java.io.File
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import timber.log.Timber

class HomeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = ""
    }
    val text: LiveData<String> = _text


    fun getTranscripts(file: File){

        val requestFile: RequestBody = RequestBody.create(MediaType.parse("application/octet-stream"), file)


        val multipartBody = MultipartBody.Part.createFormData("file", file.name, requestFile)

        viewModelScope.launch {
            ApiService.getApi().getTranscriptedText(multipartBody).enqueue(object :
                Callback<Transcript?> {
                override fun onResponse(call: Call<Transcript?>?, response: Response<Transcript?>) {
                    Timber.d("HomFragment", "success " + response.code())
                    Timber.d( "HomFragment","success " + response.message())
                    Timber.d("HomFragment","success ${response.body()?.text}")

                    _text.postValue(response.body()?.text)

                }

                override fun onFailure(call: Call<Transcript?>?, t: Throwable) {
                    Timber.d("failure", "message = " + t.message)
                    Timber.d("failure", "cause = " + t.cause)
                }
            })
        }

    }


}