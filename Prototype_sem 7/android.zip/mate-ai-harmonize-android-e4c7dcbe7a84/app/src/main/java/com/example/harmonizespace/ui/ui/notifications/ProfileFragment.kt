package com.example.harmonizespace.ui.ui.notifications

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.apollographql.apollo.ApolloClient
import com.bumptech.glide.Glide
import com.example.harmonizespace.R
import com.example.harmonizespace.databinding.FragmentProfileBinding
import com.example.harmonizespace.network.AuthorizationInterceptor
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response

class ProfileFragment : Fragment() {

    private lateinit var profileViewModel: ProfileViewModel
    private var _binding: FragmentProfileBinding? = null
    private lateinit var sharedPreferences: SharedPreferences
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        profileViewModel =
            ViewModelProvider(this).get(ProfileViewModel::class.java)

        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textNotifications
        profileViewModel.text.observe(viewLifecycleOwner, Observer {
            textView.text = it
        })


        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sharedPreferences = requireContext().getSharedPreferences(context?.getString(R.string.harmonizeSpace), Context.MODE_PRIVATE)
        val apolloClient = ApolloClient.builder()
            .serverUrl("https://development.harmonize.space/graphql")
            .okHttpClient(
                OkHttpClient.Builder()
                    .addInterceptor(AuthorizationInterceptor(requireContext()))
                    .build()
            )
            .build()

        profileViewModel.getUser(apolloClient)

        profileViewModel.user.observe(requireActivity(), Observer {
            binding.textNotifications.text = it.name
            binding.textEmail.text = it.email
            Glide
                .with(requireActivity())
                .load(it.avatar)
                .centerCrop()
                .placeholder(R.drawable.ic_dashboard_black_24dp)
                .into(binding.ivProfile);
        })
    }



    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}