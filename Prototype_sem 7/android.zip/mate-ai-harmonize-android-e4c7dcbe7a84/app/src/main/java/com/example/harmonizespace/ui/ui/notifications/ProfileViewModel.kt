package com.example.harmonizespace.ui.ui.notifications

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.apollographql.apollo.ApolloClient
import com.apollographql.apollo.exception.ApolloException

import org.jetbrains.annotations.NotNull

import com.apollographql.apollo.ApolloCall
import com.apollographql.apollo.api.Operation
import com.apollographql.apollo.api.Response
import com.apollographql.apollo.coroutines.await
import com.apollographql.apollo.coroutines.toDeferred
import com.example.apollographqlandroid.ProfileQuery
import kotlinx.coroutines.launch
import timber.log.Timber


class ProfileViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Accounts Fragment"
    }
    val text: LiveData<String> = _text

    private val _user = MutableLiveData<ProfileQuery.Profile>()
    val user: LiveData<ProfileQuery.Profile> = _user

    fun getUser( apolloClient: ApolloClient){

        viewModelScope.launch {
            val response = try {
                apolloClient.query(ProfileQuery()).await()
            } catch (e: ApolloException) {
                // handle protocol errors
                Timber.e("Apollo Exception: $e")

                return@launch
            }

            val profile = response.data?.profile
            if (profile == null || response.hasErrors()) {
                // handle application errors
                return@launch
            }
            _user.postValue(profile!!)
        }
    }
}