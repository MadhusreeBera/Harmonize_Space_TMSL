# Getting Started with Harmonize Backend Server
=========================================

Firstly, we need to setup the backend server.

### Setup

- To get started, install the required node modules:

```
npm install
```
- Then copy the sample.env to .env and configure it.

### Run
Then issue the following command to run the server:

```
npm start
```

Or use the following command to run the server in development mode:

```
nodemon
```

### Documentation

- The documentation is available at [`Gql Docs`](https://development.harmonize.space/graphql).
- To get the documention of rest apis import `Harmonize space.postman_collection.json` into Postman.