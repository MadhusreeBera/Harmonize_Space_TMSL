const isLambda = require('is-lambda');
const path = require('path');

module.exports = {
    scopes: [
        'https://www.googleapis.com/auth/calendar.events',
        'https://www.googleapis.com/auth/drive.file',
        'https://www.googleapis.com/auth/userinfo.profile',
        'https://www.googleapis.com/auth/userinfo.email'
    ],

    userStatus: {
        ACTIVE: 'ACTIVE',
        INACTIVE: 'INACTIVE'
    },
    fileStatus: {
        ACTIVE: 'ACTIVE',
        INACTIVE: 'INACTIVE'
    },
    meetStatus: {
        ACTIVE: 'ACTIVE',
        INACTIVE: 'INACTIVE'
    },

    AUTH_TOKEN_EXPIRY_HOURS: 6,
    ZOOM_LOGIN_WINDOW: 30,
    MAIN_FOLDER: '.HarmonizeSpace',

    FileTypes: {
        File: 'File',
        WEBSITE: 'WEBSITE',
        FOLDER: 'FOLDER'
    },
    meetType: {
        PRIVATE: 'PRIVATE',
        GOOGLE: 'GOOGLE',
        ZOOM: 'ZOOM'
    },

    File_Pagination_Limit: 50,
    Meet_Pagination_Limit: 20,
    Temp_Folder: isLambda ? '/tmp' : path.join(__dirname, '../temp'),
    Extensions: [
        '.jpg',
        '.png',
        '.jpeg',
        '.pdf',
        '.doc',
        '.docx',
        '.ppt',
        '.pptx',
        '.csv',
        '.json',
        '.html',
        '.mp3',
        '.webm',
        '.mp4',
        '.mov',
        '.avi',
        '.wmv',
        '.ogg',
        '.xlsx',
        '.xls'
    ],
    File_Expiration_Time: 23 * 60 * 60 * 1000
};
