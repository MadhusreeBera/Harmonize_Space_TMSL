const {
    generateGoogleAuthUrl,
    getToken,
    getUserInfo
} = require('../helpers/googleOauth');
const {
    signRefreshToken,
    sign,
    verifyRefreshToken
} = require('../helpers/tokenHelper');
const constants = require('../config/constants');
const User = require('../models/user');
const uniqId = require('uniqid');
const Zoom = require('../helpers/zoom');

exports.googleAuth = async (req, res) => {
    try {
        const existingDevice = await User.checkIfUserExists(
            req.query.deviceId,
            'devices'
        );
        const url = generateGoogleAuthUrl(!existingDevice, req.query.deviceId);
        res.render('auth/google', {
            data: {
                url
            }
        });
    } catch (e) {
        console.log(e);
        res.render('error', { message: e.message, error: e });
    }
};

exports.googleAuthCallback = async (req, res) => {
    try {
        const { code } = req.query;
        console.log(req.query);
        if (!code || code.length <= 1) {
            return {};
        }
        const token = await getToken(code);
        if (constants.scopes.some((scope) => !token.scope.includes(scope))) {
            throw new Error('Permissions not provided');
        }
        const googleUser = (await getUserInfo(token)).data;
        let existingUser = await User.checkIfUserExists(
            googleUser.id,
            'googleId'
        );
        if (!existingUser) {
            existingUser = await User.checkIfUserExists(googleUser.email);
        }
        if (!existingUser) {
            existingUser = new User({
                googleId: googleUser.id,
                email: googleUser.email,
                name: googleUser.name,
                avatar: googleUser.picture,
                googleToken: token,
                devices: [req.query.state]
            });
            await existingUser.save();
        } else {
            await User.newLogin(
                existingUser._id,
                Object.assign(existingUser.googleToken, token),
                req.query.state
            );
        }
        // existingUser.googleToken = ;

        const refreshToken = signRefreshToken({
            _id: existingUser._id
        });
        res.render('auth/google', { data: { token: refreshToken } });
    } catch (e) {
        console.log(e);
        res.render('error', { message: e.message, error: e });
    }
};

exports.refreshToken = async ({ args }) => {
    const { token } = args;
    let user = await verifyRefreshToken(token);
    if (!user) {
        throw new Error('Invalid token');
    }
    user = await User.checkIfUserExists(user._id, '_id');
    if (!user) {
        throw new Error('User not found');
    }
    if (user.status !== constants.userStatus.ACTIVE) {
        throw new Error('User not found');
    }
    const authToken = sign({
        _id: user._id,
        email: user.email,
        name: user.name,
        avatar: user.avatar
    });
    const refreshToken = signRefreshToken({
        _id: user._id
    });
    return { token: authToken, refreshToken, user };
};

exports.zoomLoginUrl = async ({ ctx }) => {
    const { user } = ctx;
    const now = new Date();
    if (user.zoomState && now < user.zoomStateValidUntil) {
        user.zoomStateValidUntil = new Date(
            user.zoomStateValidUntil.getTime() +
                constants.ZOOM_LOGIN_WINDOW * 60000
        );
    }
    if (!user.zoomState || now > user.zoomStateValidUntil) {
        user.zoomState = uniqId();
        user.zoomStateValidUntil = new Date(
            now.getTime() + constants.ZOOM_LOGIN_WINDOW * 60000
        );
    }
    await user.save();
    return { url: Zoom.zoomLoginUrl(user.zoomState) };
};

exports.zoomCallBack = async (req, res) => {
    try {
        const { state, code } = req.query;
        const user = await User.checkIfUserExists(state, 'zoomState');
        if (!user) {
            throw new Error('User not found');
        }
        if (user.zoomStateValidUntil < new Date()) {
            throw new Error(
                'Zoom login window expired. Please restart the authorization process'
            );
        }
        const token = await Zoom.zoomlogin(code);
        const zoomUser = await Zoom.zoomUser(token.access_token);
        await User.updateZoomToken(user._id, {
            zoomToken: token,
            zoomId: zoomUser.id,
            zoomEmail: zoomUser.email,
            zoomName: zoomUser.first_name + ' ' + zoomUser.last_name
        });
        res.render('auth/success', { data: {} });
    } catch (e) {
        console.log(e);
        res.render('error', { message: e.message, error: e });
    }
};
