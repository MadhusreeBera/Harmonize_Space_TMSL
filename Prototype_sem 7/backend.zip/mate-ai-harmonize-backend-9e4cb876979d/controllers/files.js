const constants = require('../config/constants');
const drive = require('../helpers/drive');
const Files = require('../models/files');

const multer = require('multer');
const path = require('path');
const Mongoose = require('mongoose');
const User = require('../models/user');
const fs = require('fs');
const { getText } = require('../helpers/transcripter');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, constants.Temp_Folder);
    },
    filename: function (req, file, cb) {
        const id = Mongoose.Types.ObjectId();
        cb(null, id + '_' + Date.now() + path.extname(file.originalname));
    }
});

exports.createFolder = async ({ args, ctx }) => {
    const { name } = args;
    const { user } = ctx;
    const folder = new Files({
        name,
        type: constants.FileTypes.FOLDER,
        userId: user._id
    });
    folder.watching();
    let driveParent = user.driveId;
    if (!driveParent) {
        throw new Error('User has not enabled drive');
    }
    if (!args.parent) {
        args.parent = user.root;
    }
    args.parent = await Files.getMyFileBYId(user._id, args.parent);
    if (!args.parent) throw new Error('Parent not found');
    if (args.parent.type != constants.FileTypes.FOLDER)
        throw new Error('Parent not a folder');
    folder.ancestorsId = [...args.parent.ancestorsId, args.parent._id];
    folder.parentId = args.parent._id;
    driveParent = args.parent.driveId;

    const driveFolder = await drive.createFolder(
        user.googleToken,
        driveParent,
        name
    );
    folder.driveId = driveFolder.id;
    folder.url = driveFolder.webViewLink;
    folder.downloadUrl = driveFolder.webContentLink;
    folder.icon = driveFolder.iconLink;
    folder.thumbnail = driveFolder.thumbnailLink;
    await folder.save();
    await drive.watch(user.googleToken, folder);
    return;
};

exports.renameFile = async ({ args, ctx }) => {
    const { user } = ctx;
    const file = await exports.singleFile({ args, ctx });
    if (file.hidden) throw new Error('File cannot be renamed');
    file.name = args.name;
    await drive.updateNameFileOrFolder(
        user.googleToken,
        file.driveId,
        args.name
    );
    if (!file.watching()) await drive.watch(user.googleToken, file);
    await file.save();
    return file;
};
exports.watchFile = async ({ args, ctx }) => {
    const { user } = ctx;
    const file = await exports.singleFile({ args, ctx });
    if (!file.watching()) {
        await drive.watch(user.googleToken, file);
        await file.save();
    }
    return file;
};

exports.moveFile = async ({ args, ctx }) => {
    const { user } = ctx;
    const file = await exports.singleFile({ args, ctx });
    if (file.hidden) throw new Error('File cannot be moved');
    const newParent = await Files.getMyFileBYId(user._id, args.parent);
    if (!newParent) throw new Error('Destination parent not found');
    const newAncestorsId = [...newParent.ancestorsId, newParent._id];
    await drive.moveFileOrFolder(
        user.googleToken,
        file.driveId,
        newParent.driveId
    );
    if (file.type == constants.FileTypes.FOLDER) {
        await Files.moveChildren(
            user._id,
            file._id,
            file.ancestorsId,
            newAncestorsId
        );
    }
    file.parentId = newParent._id;
    file.ancestorsId = newAncestorsId;

    return await file.save();
};

exports.singleFile = async ({ args, ctx }) => {
    const { id } = args;
    const { user } = ctx;
    const file = await Files.getMyFileBYId(user._id, id);
    if (!file) throw new Error('File not found');
    return file;
};
exports.deleteFile = async ({ args, ctx }) => {
    const { id } = args;
    const { user } = ctx;
    const file = await Files.deleteMyFile(user._id, id);
    if (!file) throw new Error('File not found');
    if (file.hidden) {
        await User.disableDrive(user._id);
    }
    if (file.type == constants.FileTypes.FOLDER) {
        await Files.deleteMyChildren(user._id, file._id);
    }
    if (file.type !== constants.FileTypes.WEBSITE && args.fromDrive) {
        await drive.deleteFileOrFolder(user.googleToken, file.driveId);
    }
    return file;
};

exports.allFiles = async ({ args, ctx }) => {
    const { user } = ctx;

    const sortBy = args.sortBy
        ? { [args.sortBy]: args.orderBy == 'DESC' ? -1 : 1 }
        : { createdAt: -1 };
    const filter = args.filter;
    if (filter.query) {
        filter.$text = { $search: filter.query.trim() };
        delete filter.query;
    }
    const files = await Files.getAllMyFiles(
        user._id,
        args.filter,
        args.page,
        sortBy
    );
    return {
        data: files.slice(0, constants.File_Pagination_Limit),
        hasNext: !!files[constants.File_Pagination_Limit]
    };
};

exports.File = {
    parent: (root, args, ctx) => {
        if (!root.parentId) return null;
        return exports.singleFile({ args: { id: root.parentId }, ctx });
    },
    ancestors: async (root, args, ctx) => {
        const ansestors = await Files.getMyAnsestors(
            ctx.user._id,
            root.ancestorsId
        );
        ansestors.sort(
            (a, b) =>
                root.ancestorsId.indexOf(a._id) -
                root.ancestorsId.indexOf(b._id)
        );
        return ansestors;
    },
    children: (root, args, ctx) => {
        if (root.type !== constants.FileTypes.FOLDER) return [];
        args.filter.parent = root._id;
        return exports.allFiles({ args, ctx });
    }
};

const checkSupportedFile = (fileName) => {
    return constants.Extensions.some((ext) => {
        return fileName.endsWith(ext);
    });
};
const saveFile = async (req, res) => {
    if (!req.file) {
        return res.status(200).json({ err: true, msg: 'File not found' });
    }
    const localPath = path.join(constants.Temp_Folder, req.file.filename);
    try {
        const [driveFile, text] = await Promise.all([
            drive.createFile(req.user.googleToken, req.parent.driveId, {
                name: req.headers['x-file-name'] || 'New File',
                path: localPath
            }),
            getText(fs.createReadStream(localPath)).catch((e) => {
                console.log(e);
                return '';
            })
        ]);
        const file = new Files({
            name: req.headers['x-file-name'] || 'New File',
            type: constants.FileTypes.File,
            userId: req.user._id,
            ancestorsId: [...req.parent.ancestorsId, req.parent._id],
            parentId: req.parent._id,
            driveId: driveFile.id,
            url: driveFile.webViewLink,
            downloadUrl: driveFile.webContentLink,
            icon: driveFile.iconLink,
            thumbnail: driveFile.thumbnailLink,
            text
        });
        file.watching();
        await file.save();
        await drive.watch(req.user.googleToken, file);
        res.status(200).json({ file });
    } catch (e) {
        res.status(200).json({
            err: true,
            msg: e.message
        });
    } finally {
        fs.unlinkSync(localPath);
    }
};
const updateFile = async (req, res) => {
    if (!req.file) {
        return res.status(200).json({ err: true, msg: 'File not found' });
    }
    const localPath = path.join(constants.Temp_Folder, req.file.filename);
    try {
        const [driveFile, text] = await Promise.all([
            drive.updateFile(req.user.googleToken, req.dbfile.driveId, {
                path: localPath
            }),
            getText(fs.createReadStream(localPath)).catch((e) => {
                console.log(e);
                return '';
            })
        ]);
        const dbfile = req.dbfile;
        dbfile.url = driveFile.webViewLink;
        dbfile.downloadUrl = driveFile.webContentLink;
        dbfile.icon = driveFile.iconLink;
        dbfile.thumbnail = driveFile.thumbnailLink;
        dbfile.text = text;
        if (!dbfile.watching()) await drive.watch(req.user.googleToken, dbfile);
        await dbfile.save();
        res.status(200).json({ file: dbfile });
    } catch (e) {
        res.status(200).json({
            err: true,
            msg: e.message
        });
    } finally {
        fs.unlinkSync(localPath);
    }
};
const preProcessNewFile = async (req, file) => {
    if (!checkSupportedFile(file.originalname)) {
        throw new Error('File not supported');
    }
    let parentId = req.headers['x-parent-id'];
    const user = await User.getById(req.user._id);
    if (!user) throw new Error('User not found');
    const driveParent = user.driveId;
    if (!driveParent) {
        throw new Error('User has not enabled drive');
    }
    if (!parentId) {
        parentId = user.root;
    }
    const parent = await Files.getMyFileBYId(user._id, parentId);
    if (!parent) throw new Error('Parent not found.');
    if (parent.type != constants.FileTypes.FOLDER)
        throw new Error('Parent not a folder');
    req.parent = parent;
    req.user = user;
};
const preProcessOldFile = async (req, file) => {
    if (!checkSupportedFile(file.originalname)) {
        throw new Error('File not supported');
    }
    const fileId = req.headers['x-file-id'];
    if (!fileId) throw new Error('File id not found');
    const user = await User.getById(req.user._id);
    if (!user) throw new Error('User not found');
    const driveParent = user.driveId;
    if (!driveParent) {
        throw new Error('User has not enabled drive');
    }
    const dbfile = await Files.getMyFileBYId(user._id, fileId);
    if (!dbfile) throw new Error('File not found.');
    if (dbfile.type != constants.FileTypes.File)
        throw new Error('Folder or website cannot be uploaded');
    req.dbfile = dbfile;
    req.user = user;
};
exports.uploadFile = (req, res, next) => {
    const upload = multer({
        limits: {
            fileSize: 6 * 1000 * 1000
        },
        async fileFilter(req, file, cb) {
            try {
                await preProcessNewFile(req, file);
                cb(undefined, true);
            } catch (e) {
                cb(e, false);
            }
        },
        storage: storage
    });
    return upload.single('file')(req, res, (err) => {
        if (err) return next(err);
        return saveFile(req, res, next);
    });
};

exports.updateFile = (req, res, next) => {
    const upload = multer({
        limits: {
            fileSize: 6 * 1000 * 1000
        },
        async fileFilter(req, file, cb) {
            try {
                await preProcessOldFile(req, file);
                cb(undefined, true);
            } catch (e) {
                cb(e, false);
            }
        },
        storage: storage
    });
    return upload.single('file')(req, res, (err) => {
        if (err) return next(err);
        return updateFile(req, res, next);
    });
};

exports.handleDriveNotif = async (req) => {
    try {
        const { _id, type, userId } = req.driveFile;
        const state = req.headers['x-goog-resource-state'];
        if (state == 'update') {
            const changes = req.headers['x-goog-changed'];
            if (
                !['content', 'properties', 'parents'].some((x) =>
                    changes.includes(x)
                )
            )
                throw new Error('Changes not Required');
            const user = await User.getById(userId);
            if (!user) throw new Error('User not found');
            const file = await Files.getMyFileBYId(userId, _id);
            if (!file) throw new Error('File not found');
            const driveFile = await drive.getFile(user.googleToken, file);
            if (!driveFile) throw new Error('Drive File not found');
            if (file.updatedAt >= new Date(driveFile.modifiedTime)) {
                throw new Error('File already updated');
            }
            if (
                changes.includes('content') &&
                type == constants.FileTypes.File
            ) {
                const stream = await drive.getStream(user.googleToken, file);
                stream.path = path.join(__dirname, driveFile.name);
                const text = await getText(stream);
                file.text = text;
            }
            if (changes.includes('properties')) {
                file.url = driveFile.webViewLink;
                file.downloadUrl = driveFile.webContentLink;
                file.icon = driveFile.iconLink;
                file.thumbnail = driveFile.thumbnailLink;
                file.name = driveFile.name;
            }
            if (changes.includes('parents')) {
                const parent = await Files.getMyFileBYDriveId(
                    userId,
                    driveFile.parents[0]
                );
                if (parent && file.parentId != parent._id) {
                    const newAncestorsId = [...parent.ancestorsId, parent._id];
                    if (file.type == constants.FileTypes.FOLDER) {
                        await Files.moveChildren(
                            user._id,
                            file._id,
                            file.ancestorsId,
                            newAncestorsId
                        );
                    }
                    file.parentId = parent._id;
                    file.ancestorsId = newAncestorsId;
                }
            }
            await file.save();
        }
        if (state === 'trash') {
            const user = await User.getById(userId);
            if (!user) throw new Error('User not found');
            await exports.deleteFile({
                args: { id: _id },
                ctx: { user }
            });
        }
        if (state === 'sync' && type == constants.FileTypes.File) {
            const file = await Files.getMyFileBYId(userId, _id);
            if (!file) throw new Error('File not found');
            if (file.thumbnail && file.thumnail.length > 0)
                throw new Error('File already synced');
            const user = await User.getById(userId);
            if (!user) throw new Error('User not found');
            const driveFile = await drive.getFile(user.googleToken, file);
            file.url = driveFile.webViewLink;
            file.downloadUrl = driveFile.webContentLink;
            file.icon = driveFile.iconLink;
            file.thumbnail = driveFile.thumbnailLink;
            file.name = driveFile.name;
            await file.save();
        }
        return;
    } catch (e) {
        console.log(e);
    }
};
