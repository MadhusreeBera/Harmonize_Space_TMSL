const Gmeet = require('../helpers/gmeet');
const Meet = require('../models/meetings');
const Zoom = require('../helpers/zoom');
const constants = require('../config/constants');

exports.createMeeting = async ({ args, ctx }) => {
    const meet = new Meet({
        ...args.input,
        userId: ctx.user._id
    });
    if (args.input.type === constants.meetType.GOOGLE) {
        await Gmeet.createMeeting(ctx.user.googleToken, meet);
    }
    if (args.input.type === constants.meetType.ZOOM) {
        await Zoom.createMeeting(ctx.user, meet);
    }
    await meet.save();
    return meet;
};

exports.myMeetings = async ({ args, ctx }) => {
    args.filter.userId = ctx.user._id;
    args.filter.start = {
        $gte: args.start_time,
        $lte: args.end_time
    };
    const meetings = await Meet.myMeetings(
        args.filter,
        { createdAt: -1 },
        args.page
    );
    return {
        data: meetings.slice(0, constants.Meet_Pagination_Limit),
        hasNext: !!meetings[constants.Meet_Pagination_Limit]
    };
};

exports.singleMeeting = async ({ args, ctx }) => {
    const meeting = await Meet.myMeeting(args.id, ctx.user._id);
    if (!meeting) throw new Error('Meeting not found');
    return meeting;
};
