const constants = require('../config/constants');
const { createFolder, watch } = require('../helpers/drive');
const User = require('../models/user');
const Files = require('../models/files');

exports.profile = async ({ ctx }) => {
    const user = await User.getById(ctx.user._id);
    if (!user) throw new Error('User not found');
    return user;
};

exports.enableDrive = async ({ ctx }) => {
    const { user } = ctx;
    if (user.driveId) return user;
    const folder = await createFolder(
        user.googleToken,
        null,
        constants.MAIN_FOLDER
    );
    user.driveId = folder.id;
    user.driveLink = folder.webViewLink;
    const dbFolder = new Files({
        name: 'root',
        type: constants.FileTypes.FOLDER,
        userId: user._id,
        driveId: folder.id,
        url: folder.webViewLink,
        downloadUrl: folder.webContentLink,
        hidden: true
    });
    dbFolder.watching();
    user.root = dbFolder._id;
    await dbFolder.save();
    await user.save();
    await watch(user.googleToken, dbFolder);
    return user;
};

exports.populateUser = async ({ ctx }, next) => {
    const user = await exports.profile({ ctx });
    ctx.user = user;
    next();
};

exports.User = {
    isDriveEnabled: (root) => {
        return !!root.driveId;
    }
};
