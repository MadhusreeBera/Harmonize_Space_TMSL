const { profile } = require('../controllers/user');

exports.Auth = function (prefill) {
    return async ({ ctx }, next) => {
        if (!ctx.user) {
            return next(new Error('Unauthorized'));
        }
        if (prefill && !ctx.prefill) {
            ctx.user = await profile({ ctx });
            ctx.prefill = true;
        }
        return next();
    };
};
