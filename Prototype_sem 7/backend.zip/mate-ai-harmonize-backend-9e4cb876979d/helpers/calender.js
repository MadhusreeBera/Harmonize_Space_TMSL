const { google } = require('googleapis');
// const constants = require('../config/constants');

const getCalender = (userToken) => {
    const OAuth2 = google.auth.OAuth2;
    const oauth2Client = new OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET,
        process.env.GOOGLE_REDIRECT_URI
    );
    oauth2Client.setCredentials(userToken);
    return google.calendar({ version: 'v3', auth: oauth2Client });
};

exports.createEvent = async (userToken, meet, conferenceData) => {
    const calender = getCalender(userToken);

    const calendarId = 'primary';

    const getEventDate = (eventDate) => {
        return {
            dateTime: eventDate.toJSON()
        };
    };

    const meetingAttendees = meet.participants.map((participant) => {
        return {
            email: participant.email,
            displayName: participant.displayName
            // responseStatus: 'needsAction'
        };
    });

    const meetingReminders = meet.reminders.map((reminder) => ({
        method: reminder.method,
        minutes: reminder.minutes
    }));

    const data = await calender.events
        .insert({
            calendarId: calendarId,
            sendUpdates: 'all',
            sendNotifications: true,
            supportsAttachments: true,
            resource: {
                summary: meet.name,
                description: meet.description,
                attendees: meetingAttendees,
                conferenceData,
                start: getEventDate(meet.start),
                end: getEventDate(meet.end),
                guestsCanInviteOthers: false,
                guestsCanModify: false,
                status: 'confirmed',
                reminders: {
                    useDefault: false,
                    overrides: meetingReminders
                }
            },
            conferenceDataVersion: 1
        })
        .then((res) => res.data);

    const { id } = data;
    meet.calenderId = id;
    return data;
};
