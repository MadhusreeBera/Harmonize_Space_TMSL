const { google } = require('googleapis');
const mime = require('mime/lite');
const fs = require('fs');
const { signDriveToken } = require('./tokenHelper');
// const constants = require('../config/constants');

const getDrive = (userToken) => {
    const OAuth2 = google.auth.OAuth2;
    const oauth2Client = new OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET,
        process.env.GOOGLE_REDIRECT_URI
    );
    oauth2Client.setCredentials(userToken);
    return google.drive({ version: 'v3', auth: oauth2Client });
};

exports.createFolder = (userToken, folderId, folderName) => {
    const drive = getDrive(userToken);
    const fileMetadata = {
        name: folderName,
        mimeType: 'application/vnd.google-apps.folder'
    };
    if (folderId) {
        fileMetadata.parents = [folderId];
    }
    return drive.files
        .create({
            resource: fileMetadata,
            fields: 'id,webContentLink,webViewLink,iconLink'
        })
        .then((res) => res.data);
};

exports.createFile = (userToken, folderId, file) => {
    const drive = getDrive(userToken);
    const fileMetadata = {
        name: file.name,
        parents: [folderId]
    };
    const media = {
        mimeType: mime.getType(file.path),
        body: file.content || fs.createReadStream(file.path)
    };
    return drive.files
        .create({
            resource: fileMetadata,
            media: media,
            fields: 'id,webContentLink,webViewLink,iconLink'
        })
        .then((res) => res.data);
};

exports.moveFileOrFolder = async (userToken, fileId, destinationId) => {
    const drive = getDrive(userToken);
    const file = await drive.files
        .get({
            fileId: fileId,
            fields: 'parents'
        })
        .then((res) => res.data);
    if (!file) throw new Error('File not found');
    const previousParents = file.parents.join(',');
    return drive.files
        .update({
            fileId: fileId,
            addParents: destinationId,
            removeParents: previousParents,
            fields: 'id, parents'
        })
        .then((res) => res.data);
};

exports.updateFile = async (userToken, fileId, file) => {
    const drive = getDrive(userToken);
    const media = {
        mimeType: mime.getType(file.path),
        body: file.content || fs.createReadStream(file.path)
    };
    await drive.files.update({
        fileId: fileId,
        fields: 'id',
        media
    });
    return drive.files
        .get({
            fileId: fileId,
            fields: 'id,webContentLink,webViewLink,iconLink'
        })
        .then((res) => res.data);
};

exports.updateNameFileOrFolder = (userToken, fileId, newName) => {
    const drive = getDrive(userToken);
    return drive.files
        .update({
            fileId: fileId,
            fields: 'id',
            resource: { name: newName }
        })
        .then((res) => res.data);
};
exports.deleteFileOrFolder = (userToken, fileId) => {
    const drive = getDrive(userToken);
    return drive.files
        .delete({
            fileId: fileId
        })
        .then((res) => res.data);
};

exports.getStream = (userToken, file) => {
    const drive = getDrive(userToken);
    return drive.files
        .get(
            {
                fileId: file.driveId,
                alt: 'media'
            },
            { responseType: 'stream' }
        )
        .then((res) => res.data);
};

exports.getFile = (userToken, file) => {
    const drive = getDrive(userToken);
    return drive.files
        .get({
            fileId: file.driveId,
            fields: 'id,name,webContentLink,webViewLink,thumbnailLink,iconLink,modifiedTime,parents'
        })
        .then((res) => res.data);
};

exports.about = (userToken) => {
    const drive = getDrive(userToken);
    return drive.about
        .get({
            fields: 'storageQuota'
        })
        .then((res) => res.data);
};

exports.watch = (userToken, file) => {
    const drive = getDrive(userToken);
    return drive.files
        .watch({
            fileId: file.driveId,
            requestBody: {
                kind: 'api#channel',
                id: String(file._id),
                resourceId: file.driveId,
                resourceUri: file.url,
                token: signDriveToken({
                    _id: file._id,
                    type: file.type,
                    userId: file.userId
                }),
                expiration: file.listeningTill.getTime(),
                type: 'webhook',
                address: `${process.env.APP_URL}/api/drive/watch`,
                payload: true,
                params: {}
            }
        })
        .catch(console.log);
};
