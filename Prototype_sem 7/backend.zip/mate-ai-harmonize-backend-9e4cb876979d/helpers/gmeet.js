const uniqid = require('uniqid');
const { createEvent } = require('./calender');

exports.createMeeting = async (userToken, meet) => {
    const meetingRequestId = uniqid();

    const conferenceData = {
        createRequest: {
            requestId: meetingRequestId,
            conferenceSolutionKey: {
                type: 'hangoutsMeet'
            }
        }
    };

    const { hangoutLink, htmlLink } = await createEvent(
        userToken,
        meet,
        conferenceData
    );
    meet.url = htmlLink;
    meet.joinUrl = hangoutLink;
    meet.shareUrl = hangoutLink;
    return meet;
};
