const { google } = require('googleapis');
const constants = require('../config/constants');
const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
);

exports.generateGoogleAuthUrl = (newDevice, deviceId) => {
    return oauth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: constants.scopes,
        prompt: newDevice || process.env.DEV == 'Yes' ? 'consent' : undefined,
        state: deviceId
    });
};

exports.getToken = (code) => {
    return oauth2Client.getToken(code).then((r) => r.tokens);
};

exports.getUserInfo = (tokens) => {
    const OAuth2 = google.auth.OAuth2;
    const oauth2Client = new OAuth2();
    oauth2Client.setCredentials(tokens);
    const oauth2 = google.oauth2({
        auth: oauth2Client,
        version: 'v2'
    });
    return oauth2.userinfo.get();
};
