const { verify } = require('./tokenHelper');
// const { hasPermission } = require('./userHelper');
// const { CustomError } = require('./errorHelper');
exports.context = async ({ req }) => {
    const token = req.headers.authorization;
    if (!token) return {};
    const user = await verify(req.headers.authorization).catch(() => null);
    return { user, token, service_provider: req.headers.service_provider };
};

exports.createPagedResponse = (type) => {
    return `{data:[${type}],hasNext:Boolean}`;
};

// exports.ensurePermission = (permission) => {
//     return ({ ctx }, next) => {
//         if (
//             ctx.user &&
//             hasPermission(ctx.user, permission, ctx.service_provider)
//         ) {
//             return next();
//         } else {
//             return next(new CustomError('Access Denied'));
//         }
//     };
// };
