exports.html = (req, res, next) => {
    req.html = true;
    next();
};
