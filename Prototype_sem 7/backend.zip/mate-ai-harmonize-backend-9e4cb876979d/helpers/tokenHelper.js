const jwt = require('jsonwebtoken');
const configConsts = require('../config/constants');
exports.sign = (payload) => {
    return jwt.sign(payload, process.env.TOKEN_SECRET, {
        expiresIn: configConsts.AUTH_TOKEN_EXPIRY_HOURS + 'h'
    });
};
exports.signRefreshToken = (payload) => {
    return jwt.sign(payload, process.env.REFRESH_TOKEN_SECRET);
};

exports.signDriveToken = (payload) => {
    return jwt.sign(payload, process.env.DRIVE_TOKEN_SECRET);
};

exports.verify = (token) =>
    new Promise((resolve, reject) => {
        jwt.verify(token, process.env.TOKEN_SECRET, function (err, decoded) {
            if (err) {
                return reject(err.message);
            } else {
                resolve(decoded);
            }
        });
    });
exports.verifyRefreshToken = (token) =>
    new Promise((resolve, reject) => {
        jwt.verify(
            token,
            process.env.REFRESH_TOKEN_SECRET,
            function (err, decoded) {
                if (err) {
                    return reject(err.message);
                } else {
                    resolve(decoded);
                }
            }
        );
    });
exports.verifyDriveToken = (token) =>
    new Promise((resolve, reject) => {
        jwt.verify(
            token,
            process.env.DRIVE_TOKEN_SECRET,
            function (err, decoded) {
                if (err) {
                    return reject(err.message);
                } else {
                    resolve(decoded);
                }
            }
        );
    });

exports.validate = (req, res, next) => {
    const token = req.headers['authorization'];
    // console.log(token)

    if (token) {
        exports
            .verify(token)
            .then((user) => {
                req.user = user;
                next();
            })
            .catch((err) => {
                return res.status(200).json({
                    err: true,
                    msg: err.message,
                    logout: true
                });
            });
    } else {
        return res.status(200).json({
            err: true,
            msg: 'no token supplied',
            logout: true
        });
    }
};
exports.validateRefreshToken = (req, res, next) => {
    const token = req.headers['authorization'];
    // console.log(token)

    if (token) {
        exports
            .verifyRefreshToken(token)
            .then((user) => {
                req.user = user;
                next();
            })
            .catch((err) => {
                return res.status(200).json({
                    err: true,
                    msg: err.message,
                    logout: true
                });
            });
    } else {
        return res.status(200).json({
            err: true,
            msg: 'no token supplied',
            logout: true
        });
    }
};
exports.validateDriveToken = (req, res, next) => {
    const token = req.headers['x-goog-channel-token'];
    // console.log(token)

    if (token) {
        exports
            .verifyDriveToken(token)
            .then((driveFile) => {
                req.driveFile = driveFile;
                next();
            })
            .catch((err) => {
                return res.status(200).json({
                    err: true,
                    msg: err.message,
                    logout: true
                });
            });
    } else {
        return res.status(200).json({
            err: true,
            msg: 'no token supplied',
            logout: true
        });
    }
};
