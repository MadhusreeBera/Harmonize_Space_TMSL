const FormData = require('form-data');
const axios = require('axios').default;
if (!process.env.TRANSCRIPTER_URL) {
    throw new Error('TRANSCRIPTER_URL is not defined');
}
exports.getText = (stream) => {
    const form = new FormData();
    form.append('file', stream);

    const request_config = {
        headers: {
            ...form.getHeaders()
        }
    };

    return axios
        .put(process.env.TRANSCRIPTER_URL, form, request_config)
        .then((res) => {
            console.log(res.data);
            if (res.data.error) throw new Error(res.data.error);
            return res.data.text;
        });
};
