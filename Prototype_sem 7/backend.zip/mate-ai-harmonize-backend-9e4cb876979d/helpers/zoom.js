const randomstring = require('randomstring');
const axios = require('axios').default;
const User = require('../models/user');
const { createEvent } = require('./calender');

const api = 'https://api.zoom.us/v2';
const authApi = 'https://zoom.us/oauth/token';
const getToken = (userCode) => {
    return axios
        .post(
            `${authApi}?grant_type=authorization_code&code=${userCode}&redirect_uri=${process.env.ZOOM_REDIRECT}`,
            null,
            {
                headers: {
                    Authorization: `Basic ${Buffer.from(
                        `${process.env.ZOOM_CLIENT}:${process.env.ZOOM_SECRET}`
                    ).toString('base64')}`
                }
            }
        )
        .then((res) => {
            const t = new Date();
            t.setSeconds(t.getSeconds() + res.data.expires_in - 60);
            res.data.expires_in = t;
            return res.data;
        });
};
const refreshToken = async (userId, token) => {
    const newtoken = await axios
        .post(
            `${authApi}?grant_type=refresh_token&refresh_token=${token}`,
            null,
            {
                headers: {
                    Authorization: `Basic ${Buffer.from(
                        `${process.env.ZOOM_CLIENT}:${process.env.ZOOM_SECRET}`
                    ).toString('base64')}`
                }
            }
        )
        .then((res) => {
            const t = new Date();
            t.setSeconds(t.getSeconds() + res.data.expires_in - 60);
            res.data.expires_in = t;
            return res.data;
        });
    await User.updateZoomToken(userId, newtoken);
    return newtoken;
};
const zoomUser = async (access_token) => {
    return axios
        .get(`${api}/users/me`, {
            headers: {
                Authorization: `Bearer ${access_token}`
            }
        })
        .then((res) => res.data);
};
const createMeeting = async (user, meet) => {
    if (!user.zoomToken) throw new Error('Authenticate Zoom first.');
    let userToken = user.zoomToken;
    if (userToken.expires_in < new Date()) {
        userToken = await refreshToken(user._id, userToken.refresh_token);
    }
    const zoomMeet = await axios
        .post(
            `${api}/users/me/meetings`,
            {
                topic: meet.name,
                agenda: meet.description?.slice(0, 1900) || '',
                type: 2,
                password: randomstring.generate({ length: 10 }),
                in_meeting: true,
                start_time: meet.start.toJSON(),
                duration: Math.round((meet.end - meet.start) / 1000 / 60),
                settings: {
                    alternative_hosts: '',
                    meeting_invitees: meet.participants.map((participant) => ({
                        email: participant.email
                    }))
                }
            },
            {
                headers: {
                    Authorization: `Bearer ${userToken.access_token}`
                }
            }
        )
        .then((res) => res.data);
    const conferenceData = {
        entryPoints: [
            {
                uri: zoomMeet.join_url,
                entryPointType: 'video'
            }
        ],
        conferenceSolution: {
            key: {
                type: 'addOn'
            },
            name: 'Zoom'
        },
        conferenceId: zoomMeet.id
    };
    const { htmlLink } = await createEvent(
        user.googleToken,
        meet,
        conferenceData
    );
    meet.url = htmlLink;
    meet.joinUrl = zoomMeet.start_url;
    meet.shareUrl = zoomMeet.join_url;
    meet.zoomId = zoomMeet.id;
    return meet;
};

const generateLoginUrl = async (state) => {
    // https://zoom.us/oauth/authorize?client_id=DOy1HOn3TSmX7rpr7QYQig&response_type=code&redirect_uri=https%3A%2F%2Fdevelopment.harmonize.space%2Fauth%2Fzoom
    const url = `https://zoom.us/oauth/authorize?client_id=${process.env.ZOOM_CLIENT}&response_type=code&state=${state}&redirect_uri=${process.env.ZOOM_REDIRECT}`;
    return url;
};

module.exports = {
    createMeeting,
    zoomlogin: getToken,
    refreshZoomToken: refreshToken,
    zoomLoginUrl: generateLoginUrl,
    zoomUser
};
