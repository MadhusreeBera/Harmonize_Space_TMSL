const mongoose = require('mongoose');
const constants = require('../config/constants');
const Schema = mongoose.Schema;
const fileSchema = new Schema(
    {
        name: { type: String },
        url: { type: String },
        downloadUrl: { type: String },
        type: {
            type: String,
            enum: Object.values(constants.FileTypes)
        },
        status: {
            type: String,
            enum: Object.values(constants.fileStatus),
            default: constants.fileStatus.ACTIVE
        },
        text: { type: String },
        userId: { type: mongoose.Schema.Types.ObjectId, ref: 'user' },
        ancestorsId: {
            type: [mongoose.Schema.Types.ObjectId],
            ref: 'file',
            default: []
        },
        parentId: { type: mongoose.Schema.Types.ObjectId, ref: 'file' },
        size: { type: Number, default: 0 },
        driveId: { type: String },
        hidden: { type: Boolean, default: false },
        icon: { type: String },
        thumbnail: { type: String },
        listeningTill: { type: Date }
    },
    { timestamps: true }
);

fileSchema.index({ text: 'text', name: 'text' });

fileSchema.methods.watching = function () {
    const now = new Date();
    if (this.listeningTill && now < this.listeningTill) return true;
    now.setTime(now.getTime() + constants.File_Expiration_Time);
    this.listeningTill = now;
    return false;
};

fileSchema.statics.getAllMyFiles = async function (
    userId,
    filter,
    page,
    sortBy
) {
    return Files.find({
        userId,
        status: constants.fileStatus.ACTIVE,
        hidden: false,
        ...filter
    })
        .sort(sortBy)
        .skip(Math.max(0, (page - 1) * constants.File_Pagination_Limit))
        .limit(constants.File_Pagination_Limit + 1);
};

fileSchema.statics.getMyFileBYId = async function (userId, fileId) {
    return Files.findOne({
        userId,
        status: constants.fileStatus.ACTIVE,
        _id: fileId
    });
};
fileSchema.statics.getMyFileBYDriveId = async function (userId, fileId) {
    return Files.findOne({
        userId,
        status: constants.fileStatus.ACTIVE,
        driveId: fileId
    });
};

fileSchema.statics.getMyAnsestors = async function (userId, ansestorsId) {
    return Files.find({
        userId,
        status: constants.fileStatus.ACTIVE,
        _id: { $in: ansestorsId }
    });
};

fileSchema.statics.deleteMyFile = async function (userId, fileId) {
    return Files.findOneAndUpdate(
        {
            userId,
            status: constants.fileStatus.ACTIVE,
            _id: fileId
        },
        {
            $set: {
                status: constants.fileStatus.INACTIVE
            }
        },
        { new: true }
    );
};
fileSchema.statics.deleteMyChildren = async function (userId, fileId) {
    return Files.updateMany(
        {
            userId,
            status: constants.fileStatus.ACTIVE,
            ansestorsId: fileId
        },
        {
            $set: {
                status: constants.fileStatus.INACTIVE
            }
        }
    );
};

fileSchema.statics.moveChildren = async function (
    userId,
    fileId,
    ansestorsId,
    newancestorsId
) {
    return Files.updateMany(
        {
            userId,
            status: constants.fileStatus.ACTIVE,
            hidden: false,
            ansestorsId: fileId
        },
        {
            $pull: {
                ansestorsId: { $in: ansestorsId }
            },
            $push: { ansestorsId: { $each: newancestorsId, $position: 0 } }
        }
    );
};

const Files = mongoose.model('file', fileSchema);
module.exports = Files;
