const mongoose = require('mongoose');
mongoose.Promise = Promise;
exports.connect = function () {
    mongoose.connect(process.env.MONGO_DB_URI, () => {
        console.log('Database Connected');
    });
    if (!process.env.HideMongoose) mongoose.set('debug', true);
    mongoose.connection.on('error', (err) => {
        console.log(err);
        console.log(
            'MongoDB connection error. Please make sure that MongoDB is running.'
        );
        // eslint-disable-next-line no-process-exit
        process.exit(1);
    });
};
