const mongoose = require('mongoose');
const constants = require('../config/constants');
const configConsts = require('../config/constants');
const Schema = mongoose.Schema;

const participantsSchema = new Schema({
    displayName: { type: String, default: '' },
    email: { type: String, required: true }
});

const reminderSchema = new Schema({
    method: { type: String, enum: ['email', 'popup'], required: true },
    minutes: { type: Number, required: true, min: 5 }
});

const meetSchema = new Schema(
    {
        name: { type: String, required: true },
        description: { type: String },
        userId: { type: mongoose.Types.ObjectId, ref: 'user' },
        status: {
            type: String,
            enum: Object.values(configConsts.meetStatus),
            default: configConsts.meetStatus.ACTIVE
        },
        url: { type: String },
        joinUrl: { type: String },
        shareUrl: { type: String },
        start: { type: Date },
        end: { type: Date },
        calenderId: { type: String },
        zoomId: { type: String },
        type: {
            type: String,
            enum: Object.values(configConsts.meetType),
            default: configConsts.meetType.PRIVATE
        },
        participants: { type: [participantsSchema], default: [] },
        reminders: { type: [reminderSchema], default: [] },
        avatar: { type: String }
    },
    { timestamps: true }
);

meetSchema.statics.myMeetings = (filter, sortBy, page = 1) => {
    return Meet.find(filter)
        .sort(sortBy)
        .skip((page - 1) * constants.Meet_Pagination_Limit)
        .limit(constants.Meet_Pagination_Limit + 1);
};
meetSchema.statics.myMeeting = (_id, userId) => {
    return Meet.findOne({ _id, userId });
};

const Meet = mongoose.model('meeting', meetSchema);
module.exports = Meet;
