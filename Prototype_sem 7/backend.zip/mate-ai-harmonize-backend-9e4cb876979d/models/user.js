const mongoose = require('mongoose');
const configConsts = require('../config/constants');
const Schema = mongoose.Schema;
const googleTokenSchema = new Schema({
    access_token: { type: String, required: true },
    refresh_token: { type: String, required: true },
    scope: { type: String },
    token_type: { type: String },
    id_token: { type: String },
    expiry_date: { type: Number }
});

const zoomTokenSchema = new Schema({
    access_token: { type: String, required: true },
    token_type: { type: String, enum: ['bearer'], required: true },
    refresh_token: { type: String, required: true },
    scope: { type: String },
    expires_in: { type: Date }
});

const userSchema = new Schema(
    {
        name: { type: String },
        email: { type: String, required: true, unique: true },
        status: {
            type: String,
            enum: Object.values(configConsts.userStatus),
            default: configConsts.userStatus.ACTIVE
        },

        googleId: { type: String },
        googleToken: { type: googleTokenSchema },

        zoomToken: { type: zoomTokenSchema },
        zoomState: { type: String },
        zoomStateValidUntil: { type: Date },
        zoomId: { type: String },
        zoomName: { type: String },
        zoomEmail: { type: String },

        avatar: { type: String },

        driveId: { type: String },
        driveLink: { type: String },

        devices: { type: [String], default: [] },

        root: { type: mongoose.Types.ObjectId, ref: 'file' }
    },
    { timestamps: true }
);
userSchema.statics.checkIfUserExists = async function (username, kind) {
    const where = {};
    if (!kind) {
        where['email'] = username;
    } else {
        where[kind] = username;
    }
    return await this.findOne(where);
};
userSchema.statics.newLogin = function (_id, googleToken, deviceId) {
    return User.findOneAndUpdate(
        { _id },
        { $set: { googleToken }, $addToSet: { devices: deviceId } }
    );
};

userSchema.statics.getById = async function (_id) {
    return await User.findOne({
        _id,
        status: configConsts.userStatus.ACTIVE
    });
};

userSchema.statics.disableDrive = async function (_id) {
    return await User.findOneAndUpdate(
        {
            _id,
            status: configConsts.userStatus.ACTIVE
        },
        {
            $unset: {
                driveId: '',
                driveLink: '',
                root: ''
            }
        }
    );
};
userSchema.statics.updateZoomToken = (userId, update) => {
    return User.findOneAndUpdate(
        { _id: userId },
        {
            $set: { ...update, zoomStateValidUntil: new Date() },
            $unset: { zoomState: '' }
        },
        {
            new: true
        }
    );
};

const User = mongoose.model('user', userSchema);
module.exports = User;
