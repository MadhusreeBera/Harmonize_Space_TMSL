const Controller = require('../controllers/auth');
const Router = require('graphql-router-ware');
const { Auth } = require('../helpers/auth');
module.exports = {
    Mutation: {
        refreshToken: Router(Controller.refreshToken),
        zoomAuth: Router(Auth(true), Controller.zoomLoginUrl)
    }
};
