const Controller = require('../controllers/files');
const Router = require('graphql-router-ware');
const { Auth } = require('../helpers/auth');
module.exports = {
    Query: {
        singleFile: Router(Auth(), Controller.singleFile),
        allFiles: Router(Auth(), Controller.allFiles)
    },
    Mutation: {
        createFolder: Router(Auth(true), Controller.createFolder),
        renameFile: Router(Auth(true), Controller.renameFile),
        moveFile: Router(Auth(true), Controller.moveFile),
        deleteFile: Router(Auth(true), Controller.deleteFile),
        watchMyFile: Router(Auth(true), Controller.watchFile)
    },
    File: Controller.File
};
