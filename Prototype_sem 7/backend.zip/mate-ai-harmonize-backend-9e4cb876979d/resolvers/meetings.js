const Controller = require('../controllers/meetings');
const Router = require('graphql-router-ware');
const { Auth } = require('../helpers/auth');
module.exports = {
    Query: {
        myMeetings: Router(Auth(), Controller.myMeetings),
        singleMeeting: Router(Auth(), Controller.singleMeeting)
    },
    Mutation: {
        createMeeting: Router(Auth(true), Controller.createMeeting)
    }
};
