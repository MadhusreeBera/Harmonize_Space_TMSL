const Controller = require('../controllers/user');
const Router = require('graphql-router-ware');
const { Auth } = require('../helpers/auth');
module.exports = {
    Query: {
        profile: Router(Auth(), Controller.profile)
    },
    Mutation: {
        enableDrive: Router(Auth(true), Controller.enableDrive)
    },
    User: Controller.User
};
