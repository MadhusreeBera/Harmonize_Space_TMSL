const express = require('express');
const router = express.Router();
const controller = require('../controllers/auth');
const { html } = require('../helpers/html');

router.use(html);
router.get('/googleAuth', controller.googleAuth);
router.get('/google', controller.googleAuthCallback);
router.get('/zoom', controller.zoomCallBack);

module.exports = router;
