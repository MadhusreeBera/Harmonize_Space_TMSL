const express = require('express');
const { handleDriveNotif } = require('../controllers/files');
const { validateDriveToken } = require('../helpers/tokenHelper');
const router = express.Router();

router.post('/watch', validateDriveToken, async (req, res) => {
    const data = {
        query: req.query,
        body: req.body,
        headers: req.headers,
        driveFile: req.driveFile
    };

    res.status(200).json({ status: 'ok' });
    await handleDriveNotif(data);
});

module.exports = router;
