const express = require('express');
const router = express.Router();
const controller = require('../controllers/files');
const { validate } = require('../helpers/tokenHelper');

router.put('/upload', validate, controller.uploadFile);
router.put('/update', validate, controller.updateFile);

module.exports = router;
