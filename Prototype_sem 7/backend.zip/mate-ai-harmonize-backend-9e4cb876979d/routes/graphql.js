const express = require('express');
const router = express.Router();
const { mergeTypeDefs, mergeResolvers } = require('@graphql-tools/merge');

const { GraphQLJSON } = require('graphql-type-json');
const { gql, ApolloServer } = require('apollo-server-express');
const { GraphQLScalarType, GraphQLError } = require('graphql');
const { Joi } = require('express-validation');

const url = require('url');

const AuthResolver = require('../resolvers/auth');
const AuthSchema = require('../schemas/auth');

const MeetingResolver = require('../resolvers/meetings');
const MeetingSchema = require('../schemas/meetings');

const FilesResolver = require('../resolvers/files');
const FilesSchema = require('../schemas/files');

const UserResolver = require('../resolvers/user');
const UserSchema = require('../schemas/user');

const { context } = require('../helpers/graphql');

const dateScalar = new GraphQLScalarType({
    name: 'Date',
    parseValue(value) {
        return new Date(value);
    },
    serialize(value) {
        return value.toISOString();
    }
});
const emailScalar = new GraphQLScalarType({
    name: 'Email',
    parseValue(value) {
        const schema = Joi.string().email();
        const { error } = schema.validate(value);
        if (error) throw error;
        return value;
    },
    serialize(value) {
        return value;
    }
});
const urlParser = (value) => {
    value = String(value).trim();
    try {
        // eslint-disable-next-line node/no-deprecated-api
        value = url.parse(value);
        if (!value.protocol) {
            throw new GraphQLError('Protocol not defined');
        }
        return value.href.trim();
    } catch (e) {
        throw new GraphQLError('Invalid url');
    }
};
const urlScalar = new GraphQLScalarType({
    name: 'URL',
    parseValue: urlParser,
    serialize: urlParser
});
const resolveJson = {
    JSON: GraphQLJSON,
    Date: dateScalar,
    URL: urlScalar,
    EMAIL: emailScalar
};

const typeDefs = mergeTypeDefs([
    gql`
        scalar Date
        scalar JSON
        scalar URL
        scalar EMAIL
        type Success {
            success: Boolean
        }
        enum OrderBy {
            ASC
            DESC
        }
    `,
    AuthSchema,
    FilesSchema,
    UserSchema,
    MeetingSchema
]);
const resolvers = mergeResolvers([
    resolveJson,
    AuthResolver,
    FilesResolver,
    UserResolver,
    MeetingResolver
]);

const server = new ApolloServer({
    typeDefs,
    resolvers,
    introspection: process.env.GRAPHQL_INTROSPECTION,
    playground: process.env.GRAPHQL_PLAYGROUND,
    engine: {
        debugPrintReports: true
    },
    context: context,
    formatError: (err) => {
        console.log(new Error(err));
        return err;
    }
});
server.start().then(() => server.applyMiddleware({ app: router, path: '/' }));

module.exports = router;
