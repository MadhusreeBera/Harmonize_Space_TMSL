module.exports = (app) => {
    app.use('/api/drive', require('./drive'));
    app.use('/transcript', require('./transcript'));
    app.use('/auth', require('./auth'));
    app.use('/graphql', require('./graphql'));
    app.use('/files', require('./files'));
};
