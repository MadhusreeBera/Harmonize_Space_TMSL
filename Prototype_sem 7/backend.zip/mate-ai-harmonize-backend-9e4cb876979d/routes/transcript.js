const express = require('express');
const { validate } = require('../helpers/tokenHelper');
const router = express.Router();

router.post('/', validate, async (req, res) => {
    res.redirect(process.env.TRANSCRIPTER_URL, 307);
});
router.put('/', validate, async (req, res) => {
    res.redirect(process.env.TRANSCRIPTER_URL, 307);
});

module.exports = router;
