const { gql } = require('apollo-server-express');
const { createPagedResponse } = require('../helpers/graphql');
const AppSchema = gql`
    type pagedApps
    ${createPagedResponse('App')}
    type App {
        _id: ID
        name: String
        url: URL
        createdAt: Date
        updatedAt: Date
    }
    input AppInput {
        name: String!
        url: URL!
    }
    type Query {
        allApps: pagedApps
    }
    type Mutation {
        createApp(input: AppInput!): App
    }
`;
module.exports = AppSchema;
