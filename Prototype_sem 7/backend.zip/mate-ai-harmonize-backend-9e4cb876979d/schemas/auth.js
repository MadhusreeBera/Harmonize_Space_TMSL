const { gql } = require('apollo-server-express');
const AuthSchema = gql`
    type Auth {
        token: String!
        refreshToken: String!
        user: User
    }
    type ZoomAuthUrl {
        url: URL!
    }
    type Mutation {
        refreshToken(token: String!): Auth
        zoomAuth: ZoomAuthUrl
    }
`;
module.exports = AuthSchema;
