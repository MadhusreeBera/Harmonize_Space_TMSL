const { gql } = require('apollo-server-express');
const constants = require('../config/constants');
const { createPagedResponse } = require('../helpers/graphql');
const FileSchema = gql`
    enum FileType
    ${'{\n' + Object.values(constants.FileTypes).join('\n') + '}\n'}

    enum FileStatus
    ${'{\n' + Object.values(constants.fileStatus).join('\n') + '}\n'}

    enum FileSortBy {
        createdAt
        updatedAt
        name
    }
    input FileFilter {
        query: String
        type: FileType
        parentId: ID
    }
    type PaggedFiles
    ${createPagedResponse('File')}

    type File {
        _id: ID!
        name: String
        url: String
        downloadUrl: String
        type: FileType
        status: FileStatus
        userId: ID
        ancestorsId: [ID]!
        ancestors: [File]!
        children(
            sortBy: FileSortBy
            orderBy: OrderBy
            filter: FileFilter!
            page: Int!
        ): PaggedFiles
        parentId: ID
        parent: File
        createdAt: Date
        updatedAt: Date
        icon: String
        thumbnail: String
        listeningTill: Date
    }
    type Query {
        singleFile(id: ID!): File
        allFiles(
            sortBy: FileSortBy
            orderBy: OrderBy
            filter: FileFilter!
            page: Int!
        ): PaggedFiles
    }
    type Mutation {
        createFolder(name: String!, parent: ID!): File
        renameFile(id: ID!, name: String!): File
        moveFile(id: ID!, parent: ID!): File
        deleteFile(id: ID!, fromDrive: Boolean!): File
        watchMyFile(id: ID!): File
    }
`;

module.exports = FileSchema;
