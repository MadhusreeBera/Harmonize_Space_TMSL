const { gql } = require('apollo-server-express');
const constants = require('../config/constants');
const { createPagedResponse } = require('../helpers/graphql');
const MeetingSchema = gql`
    enum MeetingStatus
    ${'{\n' + Object.values(constants.meetStatus).join('\n') + '}\n'}

    enum MeetingType
    ${'{\n' + Object.values(constants.meetType).join('\n') + '}\n'}

    type PaggedMeetings
    ${createPagedResponse('Meeting')}

    enum MeetingReminderMethods {
        email
        popup
    }
    type MeetingParticipant {
        displayName: String
        email: EMAIL
    }
    type MeetingReminder {
        method: MeetingReminderMethods
        minutes: Int!
    }
    type Meeting {
        _id: ID!
        name: String
        description: String
        start: Date
        end: Date
        url: URL
        joinUrl: URL
        shareUrl: URL
        type: MeetingType
        status: MeetingStatus
        reminders: [MeetingReminder]
        participants: [MeetingParticipant]
        avatar: String
        zoomId: ID
        calenderId: ID
    }
    input MeetingReminderInput {
        method: MeetingReminderMethods!
        minutes: Int!
    }
    input MeetingParticipantInput {
        displayName: String
        email: EMAIL!
    }
    input MeetingInput {
        name: String!
        description: String
        start: Date!
        end: Date!
        type: MeetingType!
        reminders: [MeetingReminderInput]!
        participants: [MeetingParticipantInput]!
        avatar: String
    }
    input MeetingsFilter {
        status: MeetingStatus
        type: MeetingType
        search: String
    }
    type Query {
        myMeetings(
            filter: MeetingsFilter!
            page: Int!
            start_time: Date!
            end_time: Date!
        ): PaggedMeetings!
        singleMeeting(id: ID!): Meeting
    }
    type Mutation {
        createMeeting(input: MeetingInput!): Meeting
    }
`;
module.exports = MeetingSchema;
