const { gql } = require('apollo-server-express');
const constants = require('../config/constants');
const UserSchema = gql`
    enum UserStatus
    ${'{\n' + Object.values(constants.userStatus).join('\n') + '}\n'}

    type User {
        _id: ID!
        name: String
        email: String
        status: UserStatus
        avatar: String
        isDriveEnabled: Boolean
        driveLink: String
        root: ID
        rootFolder: File
        zoomId: ID
        zoomName: ID
        zoomEmail: ID
    }
    type Query {
        profile: User
    }
    type Mutation {
        enableDrive: User
    }
`;
module.exports = UserSchema;
