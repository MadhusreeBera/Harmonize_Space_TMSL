import "./App.css";
import { AuthProvider } from "./context/Authentication/AuthProvider";
import { HashRouter } from "react-router-dom";
import ElectronRoutes from "./components/Routes";
import { useEffect } from "react";
// const { systemPreferences } = require("electron");

const App = () => {
  useEffect(() => {
    (async () => {
      // systemPreferences.askForMediaAccess("microphone");
    })();
  }, []);
  return (
    <AuthProvider>
      <HashRouter>
        <ElectronRoutes />
      </HashRouter>
    </AuthProvider>
  );
};

export default App;
