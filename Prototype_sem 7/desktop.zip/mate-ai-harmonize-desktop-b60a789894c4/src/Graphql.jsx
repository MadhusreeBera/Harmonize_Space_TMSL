import { InMemoryCache, createHttpLink, ApolloClient } from "@apollo/client";
import { setContext } from "@apollo/client/link/context";
import { gqlURL } from "./config";
const electron = window.require("electron");
const { ipcRenderer } = electron;

const cache = new InMemoryCache();

const defaultOptions = {
  watchQuery: {
    fetchPolicy: "no-cache",
    errorPolicy: "ignore",
  },
  query: {
    fetchPolicy: "no-cache",
    errorPolicy: "all",
  },
};

const httpLink = createHttpLink({
  uri: gqlURL,
});

const authLink = setContext(async (_, { headers }) => {
  const token = await ipcRenderer.invoke("getStoreValue", "@token");
  console.log({ token });
  return {
    headers: {
      ...headers,
      Authorization: token,
    },
  };
});

export const client = new ApolloClient({
  link: authLink.concat(httpLink),
  cache,
  defaultOptions: gqlURL && defaultOptions,
});
