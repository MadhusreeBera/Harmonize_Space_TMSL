import React from "react";
import Lottie from "react-lottie";
import styles from "./Cards.module.css";
import { BiChevronRight } from "react-icons/bi";
import { useNavigate } from "react-router-dom";

const Cards = ({ description, name }) => {
  const navigation = useNavigate();
  const handleClick = () => {
    navigation(`/${name}`);
  };
  return (
    <div className={styles.cardContainer}>
      <div className={styles.lottie}>
        <Lottie
          style={{
            borderRadius: "10%",
          }}
          options={{
            loop: false,
            autoplay: true,
            animationData: require(`../../assets/Lottie/${name}.json`),
          }}
        />
      </div>
      <div className={styles.cardTitle} onClick={() => handleClick()}>
        <p>{description}</p>
        <BiChevronRight size={30} />
      </div>
    </div>
  );
};

export default Cards;
