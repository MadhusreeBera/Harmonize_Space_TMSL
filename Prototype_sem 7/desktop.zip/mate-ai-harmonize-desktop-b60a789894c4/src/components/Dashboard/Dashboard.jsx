import React from "react";
import Profile from "../Profile/Profile";
import styles from "./Dashboard.module.css";
import Cards from "../Cards/Cards";

const Dashboard = () => {
  return (
    <div className={styles.dashBoardWrapper}>
      <h3 className={styles.title}>My Dashboard</h3>
      <div className={styles.mainCard}>
        <Cards description={"Start Meeting Assistant"} name={"meeting"} />
      </div>
      <Profile />
    </div>
  );
};

export default Dashboard;
