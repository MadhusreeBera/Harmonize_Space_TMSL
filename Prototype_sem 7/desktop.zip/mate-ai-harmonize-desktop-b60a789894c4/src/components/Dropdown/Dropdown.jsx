import React, { useState } from "react";
import { MdMail, MdPerson } from "react-icons/md";
import styles from "./Dropdown.module.css";
import { CSSTransition } from "react-transition-group";

const Dropdown = ({ user }) => {
  const [menuHeight, setMenuHeight] = useState(null);

  const calcheight = (e) => {
    const height = e.offsetHeight;
    setMenuHeight(height);
  };

  console.log(user);

  return (
    <div className={styles.dropdown} style={{ height: menuHeight }}>
      <CSSTransition in={true} unmountOnExit timeout={500} onEnter={calcheight}>
        <>
          <DropdownItem icon={<MdPerson />} title={user.name}></DropdownItem>
          <DropdownItem icon={<MdMail />} title={user.email}></DropdownItem>
        </>
      </CSSTransition>
    </div>
  );
};

const DropdownItem = ({ title, icon }) => {
  return (
    <a className={styles.dropdownItem}>
      <span className={styles.icon}>{icon}</span>
      <p>{title}</p>
    </a>
  );
};

export default Dropdown;
