import React from "react";
import style from "./Loading.module.css";
import Lottie from "react-lottie";

const Loading = () => {
  return (
    <div className={style.loaderContainer}>
      <Lottie
        options={{
          loop: true,
          autoplay: true,
          animationData: require("../../assets/Lottie/loader.json"),
        }}
      />
    </div>
  );
};

export default Loading;
