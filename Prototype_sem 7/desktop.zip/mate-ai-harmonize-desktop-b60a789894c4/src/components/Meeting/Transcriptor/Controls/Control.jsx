import React, { useEffect, useState } from "react";
import styles from "./Control.module.css";
import { BiPlayCircle } from "react-icons/bi";
import {
  MdClose,
  MdOutlinePauseCircleOutline,
  MdMic,
  MdMicOff,
  MdVideocam,
  MdVideocamOff,
} from "react-icons/md";
import { ImStop } from "react-icons/im";
import { Chip } from "@mui/material";
import Tooltip, { tooltipClasses } from "@mui/material/Tooltip";
import { styled } from "@mui/material/styles";
import { Decoder, Encoder, tools, Reader } from "ts-ebml";
const electron = window.require("electron");
const { ipcRenderer } = electron;
const fs = electron.remote.require("fs");
const path = electron.remote.require("path");
const os = electron.remote.require("os");

const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: theme.palette.common.white,
    color: "rgba(0, 0, 0, 0.87)",
    boxShadow: theme.shadows[1],
    fontSize: 20,
    padding: 12,
    marginBottom: 15,
  },
}));

const readAsArrayBuffer = (blob) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsArrayBuffer(blob);
    reader.onloadend = () => {
      resolve(reader.result);
    };
    reader.onerror = (ev) => {
      reject(ev.error);
    };
  });
};
const injectMetadata = async (blob) => {
  const decoder = new Decoder();
  const reader = new Reader();
  reader.logging = false;
  reader.drop_default_duration = false;
  return readAsArrayBuffer(blob).then((buffer) => {
    const elms = decoder.decode(buffer);
    elms.forEach((elm) => {
      reader.read(elm);
    });
    reader.stop();
    const refinedMetadataBuf = tools.makeMetadataSeekable(
      reader.metadatas,
      reader.duration,
      reader.cues
    );
    const body = buffer.slice(reader.metadataSize);
    return new Blob([refinedMetadataBuf, body], { type: "audio/webm" });
  });
};

const controls = ["play", "pause", "stop"];
const d = [
  {
    key: 0,
    label: "Angular Laboris sunt cillum ",
  },
  {
    key: 1,
    label: "jQuery Esse fugiat deserunt ",
  },
  {
    key: 2,
    label: "Polymer Incididunt adipisicing ",
  },
  {
    key: 0,
    label: "Angular Laboris sunt cillum esse ",
  },
  {
    key: 1,
    label: "jQuery Esse fugiat deserunt ",
  },
  {
    key: 2,
    label: "Polymer Incididunt adipisicing ",
  },
  {
    key: 0,
    label: "Angular Laboris sunt cillum esse ",
  },
  {
    key: 1,
    label: "jQuery Esse fugiat deserunt ",
  },
  {
    key: 2,
    label: "Polymer Incididunt ",
  },
];

let newStream, newRecorder, blobs, processing;

const Control = ({ activeScreen, setActiveScreen }) => {
  const [isMicOn, setIsMicOn] = useState(true);
  const [isCamOn, setIsCamOn] = useState(false);
  const [controlStatus, setControlStatus] = useState(
    new Array(controls.length).fill(false)
  );
  const [dataArr, setDataARR] = useState([]);
  const [stream, setStream] = useState(null);
  const [streaming, setStreaming] = useState(false);
  const [recorder, setRecorder] = useState(null);
  const [transcripts, setTranscripts] = useState([]);
  const [error, setError] = useState(null);
  const [enterVal, setInterVal] = useState(null);

  useEffect(() => {
    const updatedcontrolStatus = controlStatus.map(
      (item, index) => index === 0 && !item
    );
    setControlStatus(updatedcontrolStatus);

    console.log("controlStatus", activeScreen);
  }, []);

  useEffect(() => {
    (async () => await handleRecordActions())();
  }, []);

  const handleRecordActions = async () => {
    const { id } = activeScreen;
    try {
      // console.log("here", navigator);
      const system = await ipcRenderer.invoke("getOs");
      console.log({ system });
      if (!system) {
        throw new Error("System not supported");
      }

      const constraints = {
        audio: false,
        video: false,
      };

      if (system === "linux") {
        let devices = await navigator.mediaDevices.enumerateDevices();
        // console.log({ devices });

        devices = devices.filter(
          (device) => device.label === "harmonize_desktop"
        );
        if (devices.length === 0) {
          throw new Error("Please reinstall the application");
        }

        const device = devices[0];
        constraints.audio = {
          deviceId: {
            exact: device.deviceId,
          },
        };
      }

      if (system === "windows") {
        constraints.audio = {
          mandatory: {
            chromeMediaSource: "desktop",
            chromeMediaSourceId: id,
          },
        };
        constraints.video = {
          mandatory: {
            chromeMediaSource: "desktop",
            chromeMediaSourceId: id,
          },
        };
      }

      newStream = await navigator.mediaDevices.getUserMedia(constraints);
      newStream.stop = function () {
        newStream.getAudioTracks().forEach(function (track) {
          track.stop();
        });
        newStream.getVideoTracks().forEach(function (track) {
          track.stop();
        });
      };
      newStream.getVideoTracks().forEach(function (track) {
        //in handlenewStreamcase... :)
        newStream.removeTrack(track);
      });
      setStream(newStream);
      handleStream(newStream);

      // console.log({ stream, d: stream.getAudioTracks() });
    } catch (e) {
      console.log(e);
    }
  };

  const handleMic = () => {
    setIsMicOn(!isMicOn);
  };

  const handleVideo = () => {
    setIsCamOn(!isCamOn);
  };

  const handleStream = (stream) => {
    console.log("stream", stream);
    newRecorder = new MediaRecorder(stream);
    newRecorder.ondataavailable = async (e) => {
      if (e.data.size === 0) {
        return;
      }

      let blob = await injectMetadata(e.data);
      uploadblob(blob, "audio.webm");
    };

    blobs = [];
    newRecorder.start();

    setStreaming(true);
    setInterVal(
      setInterval(() => {
        newRecorder.stop();
        newRecorder.start();
      }, 4000)
    );
  };

  const stopStream = () => {
    newRecorder.stop();
    setStreaming(false);
    setStream(null);
    clearInterval(enterVal);
  };

  const uploadblob = async (blob, filename) => {
    let form = new FormData();
    form.append("file", new File([blob], filename));
    fetch("https://trans.harmonize.space", {
      method: "PUT",
      body: form,
    })
      .then((res) => res.json())
      .then((data) => {
        if (!data.text || data.text.length == 0) {
          return;
        }
        console.log(data);

        let textArr = [];

        textArr.push({
          key: dataArr.length,
          label: data.text,
        });
        return setDataARR((prev) => [...prev, ...textArr]);
      })
      .catch((e) => {
        console.log({ e });
      });
  };

  const handleOnChange = (position) => {
    const updatedcontrolStatus = controlStatus.map(
      (item, index) => index === position && !item
    );

    setControlStatus(updatedcontrolStatus);
  };

  const handlePause = () => {
    newRecorder.stop();
  };

  return (
    <div className={styles.meetingContainer}>
      <div className={styles.left}>
        <p className={styles.title}>Active Screens</p>
        <div className={styles.activeScreenWrapper}>
          <div className={styles.screenAct} key={activeScreen.id}>
            <img
              className={styles.screenImage}
              src={activeScreen.thumbnail.toDataURL()}
            />
            <p className={styles.screenTitle}>{activeScreen.name}</p>
          </div>
        </div>
      </div>
      <div className={styles.right}>
        <p className={styles.title}>Transcripted Text</p>
        <div className={styles.chipContainer}>
          {dataArr.map((d, idx) => (
            <Chip
              key={idx}
              className={styles.chip}
              icon={MdClose}
              label={d.label}
            />
          ))}
        </div>
      </div>
      <div className={styles.controller}>
        <div className={styles.cont}>
          <LightTooltip title="Play" placement="right">
            <div>
              <BiPlayCircle
                onClick={() => {
                  handleOnChange(0);
                }}
                size={40}
                color={controlStatus[0] ? "green" : "white"}
              />
            </div>
          </LightTooltip>
          <LightTooltip title="Pause(Commming Soon)" placement="top">
            <div>
              <MdOutlinePauseCircleOutline
                onClick={() => {
                  handleOnChange(1);
                }}
                size={40}
                color={controlStatus[1] ? "yellow" : "white"}
              />
            </div>
          </LightTooltip>
          <LightTooltip title="Stop" placement="top">
            <div>
              <ImStop
                onClick={() => {
                  handleOnChange(2);
                  stopStream();
                }}
                size={40}
                color={controlStatus[2] ? "red" : "white"}
              />
            </div>
          </LightTooltip>
          <LightTooltip title="Mic on/off(Comming Soon)" placement="top">
            <div>
              {isMicOn ? (
                <MdMic onClick={() => handleMic()} size={50} color={"white"} />
              ) : (
                <MdMicOff
                  onClick={() => handleMic()}
                  size={40}
                  color={"white"}
                />
              )}
            </div>
          </LightTooltip>
          <LightTooltip title="Video on/off(Comming Soon)" placement="top">
            <div>
              {isCamOn ? (
                <MdVideocam
                  onClick={() => handleVideo()}
                  size={40}
                  color={"white"}
                />
              ) : (
                <MdVideocamOff
                  onClick={() => handleVideo()}
                  size={40}
                  color={"white"}
                />
              )}
            </div>
          </LightTooltip>
        </div>
      </div>
    </div>
  );
};

export default Control;
