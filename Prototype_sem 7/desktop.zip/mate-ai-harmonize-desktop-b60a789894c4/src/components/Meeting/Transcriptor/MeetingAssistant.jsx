import React, { useEffect, useState } from "react";
import Profile from "../../Profile/Profile";
import Control from "./Controls/Control";
import styles from "./MeetingAssistant.module.css";
import { IoArrowBack } from "react-icons/io5";
import { useNavigate } from "react-router-dom";

const electron = window.require("electron");

const MeetingAssistant = () => {
  const [screens, setScreens] = useState([]);
  const natigation = useNavigate();
  const [activeScreen, setActiveScreen] = useState(null);

  useEffect(() => {
    electron.desktopCapturer
      .getSources({ types: ["window", "screen"] })
      .then((source) => {
        setScreens(source);
      })
      .catch((e) => {
        console.log({ e });
      });

    return () => {
      setScreens([]);
      setActiveScreen(null);
    };
  }, []);

  const handleScreenClick = async (screen) => {
    setActiveScreen(screen);
  };

  const handleBack = () => {
    natigation(`/`);
  };

  return (
    <div className={styles.meetingAssistantContainer}>
      {!activeScreen ? (
        <div className={styles.back}>
          <IoArrowBack size={30} color={"white"} onClick={() => handleBack()} />
        </div>
      ) : (
        <div className={styles.back}>
          <IoArrowBack
            size={30}
            color={"white"}
            onClick={() => setActiveScreen(null)}
          />
        </div>
      )}
      <h3 className={styles.title}>Meeting Assistant</h3>
      <Profile />
      {!activeScreen ? (
        <div className={styles.meetingContainer}>
          <div className={styles.left}>
            <p className={styles.title}>Available Screens</p>
            <div className={styles.screens}>
              {screens.map((screen) => (
                <div
                  className={styles.screen}
                  key={screen.id}
                  onClick={() => handleScreenClick(screen)}
                >
                  <img
                    className={styles.screenImage}
                    src={screen.thumbnail.toDataURL()}
                  />
                  <p className={styles.screenTitle}>
                    {screen.name.slice(0, 20) + "..."}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <Control
          activeScreen={activeScreen}
          setActiveScreen={setActiveScreen}
        />
      )}
    </div>
  );
};

export default MeetingAssistant;

//
