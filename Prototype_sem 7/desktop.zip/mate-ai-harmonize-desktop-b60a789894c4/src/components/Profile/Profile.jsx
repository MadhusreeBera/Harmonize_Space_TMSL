import React, { useContext, useState } from "react";
import { format } from "date-fns";
import styles from "./Profile.module.css";
import { BiChevronDown } from "react-icons/bi";
import AuthContext from "../../context/Authentication/AuthProvider";
import Dropdown from "../Dropdown/Dropdown";

const today = new Date();
const Profile = () => {
  const [date, _setDate] = useState(today);
  const { user } = useContext(AuthContext);
  const [dropdown, setDropdown] = useState(false);

  return (
    <div className={styles.profile}>
      <div className={styles.profileName}>
        <p className={styles.date}>{format(date, "dd MMM, yyyy")}</p>
      </div>
      <img src={user.avatar} className={styles.avatar} />
      <BiChevronDown
        size={30}
        style={{ marginLeft: "0.5em", cursor: "pointer" }}
        onClick={() => setDropdown(!dropdown)}
      />

      {dropdown && <Dropdown user={user} />}
    </div>
  );
};

export default Profile;
{
  /* <p className={styles.userName}>{user.name}</p>
              <a className={styles.userEmail} href={`mailto:${user.email}`}>
                {user.email}
              </a> */
}
