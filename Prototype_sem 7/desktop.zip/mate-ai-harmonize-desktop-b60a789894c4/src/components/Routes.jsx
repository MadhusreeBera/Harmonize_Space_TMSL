import React from "react";
import { Route, Routes } from "react-router-dom";
import Dashboard from "./Dashboard/Dashboard";
import MeetingAssistant from "./Meeting/Transcriptor/MeetingAssistant";

const ElectronRoutes = () => {
  return (
    <>
      <Routes>
        <Route exact path="/" element={<Dashboard />}></Route>
        <Route exact path="/meeting" element={<MeetingAssistant />}></Route>
      </Routes>
    </>
  );
};

export default ElectronRoutes;
