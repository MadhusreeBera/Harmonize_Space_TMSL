import React from "react";
import styles from "./Sidebar.module.css";

const Sidebar = () => {
  return <div></div>;
};

export default Sidebar;
