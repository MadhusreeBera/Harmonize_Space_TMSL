import React from "react";
import { Alert, Button, Container } from "react-bootstrap";
import convert from "../utils/covert";
const electron = window.require("electron");
const fs = electron.remote.require("fs");
const path = electron.remote.require("path");
const os = electron.remote.require("os");

let stream, recorder, blobs, processing;

class List extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      screens: [],
      err: null,
      streaming: false,
      stream: null,
      recorder: null,
      trans: [],
    };
  }
  componentDidMount() {
    electron.desktopCapturer
      .getSources({ types: ["window", "screen"] })
      .then((sources) => {
        console.log(sources);
        this.setState({
          err: null,
          screens: sources,
        });
      })
      .catch((e) => {
        console.log(e);
        return this.setState({
          err: String(e),
        });
      });
  }
  async handleClick(id) {
    try {
      console.log("here");
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          mandatory: {
            chromeMediaSource: "desktop",
            chromeMediaSourceId: id,
          },
        },
        video: {
          mandatory: {
            chromeMediaSource: "desktop",
            chromeMediaSourceId: id,
          },
        },
      });
      stream.stop = function () {
        this.getAudioTracks().forEach(function (track) {
          track.stop();
        });
        this.getVideoTracks().forEach(function (track) {
          //in case... :)
          track.stop();
        });
      };
      stream.getVideoTracks().forEach(function (track) {
        //in case... :)
        stream.removeTrack(track);
      });
      this.handleStream(stream);
      this.setState({
        stream,
      });
    } catch (e) {
      return this.setState({
        err: String(e),
      });
    }
  }
  handleStream(stream) {
    blobs = [];
    processing = false;
    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = function (event) {
      const blob = event.data;
      blobs.push(blob);
      if (processing) return;
      processing = true;
      let bl = new Blob(blobs, { type: "audio/webm" });
      blobs = [];
      // pointer.uploadfile(pointer.blobToFile(bl,"audio.webm"));
      pointer.toArrayBuffer(bl, function (ab) {
        let buffer = pointer.toBuffer(ab);
        fs.writeFile(
          path.join(os.homedir(), "harmonize-space", ".temp", "audio.webm"),
          buffer,
          async function (err) {
            console.log(err);
            if (err) {
              pointer.setState({ err: "Failed to save video " + err });
            } else {
              console.log("saved");
              try {
                pointer.uploadfile(
                  path.join(
                    os.homedir(),
                    "harmonize-space",
                    ".temp",
                    "audio.webm"
                  )
                );
              } catch (e) {
                console.log(e);
              }
              processing = false;
            }
          }
        );
      });
    };

    blobs = [];
    const pointer = this;

    recorder.start();
    this.setState({
      streaming: true,
      inter: setInterval(() => {
        recorder.stop();
        recorder.start();
      }, 4000),
    });
  }
  stopStream() {
    clearInterval(this.state.inter);
    recorder.stop();
    stream.stop();
    this.setState({
      streaming: false,
      stream: null,
    });
  }
  toArrayBuffer(blob, cb) {
    let fileReader = new FileReader();
    fileReader.onload = function () {
      let arrayBuffer = this.result;
      cb(arrayBuffer);
    };
    fileReader.readAsArrayBuffer(blob);
  }

  toBuffer(ab) {
    return Buffer.from(ab);
  }
  blobToFile(theBlob, fileName) {
    theBlob.lastModifiedDate = new Date();
    theBlob.name = fileName;
    return theBlob;
  }
  async uploadfile(file) {
    console.log("uploading");
    let form = new FormData();
    let response = await fetch(file); // give local file path stored at appdata folder
    let data = await response.blob();
    form.append("file", new File([data], "audio.wav"));
    fetch("https://trans.harmonize.space", {
      method: "PUT",
      body: form,
    })
      .then((r) => {
        if (r.ok) {
          return r.text();
        }

        throw new Error("Something went wrong.");
      })
      .then((t) => {
        let trans = this.state.trans;
        trans.push(t);
        this.setState({
          trans,
        });
      })
      .catch((e) => {});
  }
  render() {
    return (
      <Container>
        {this.state.streaming ? (
          <div>
            <center>
              <Button
                variant="danger"
                onClick={() => {
                  this.stopStream();
                }}
              >
                Stop
              </Button>
            </center>
          </div>
        ) : (
          <div>
            {this.state.screens.map((screen) => (
              <Alert key={screen.id} variant={"info"}>
                {screen.name}{" "}
                <Button
                  variant="primary"
                  onClick={() => {
                    this.handleClick(screen.id);
                  }}
                >
                  Choose
                </Button>
              </Alert>
            ))}
            {this.state.err && (
              <Alert variant={"danger"}>{this.state.err}</Alert>
            )}
          </div>
        )}
        <div style={{ display: "flex" }}>
          {this.state.trans.map((tran, id) => (
            <Alert
              key={id}
              variant={"success"}
              style={{ maxWidth: "350px", padding: "5px" }}
            >
              {tran}
            </Alert>
          ))}
        </div>
      </Container>
    );
  }
}
export default List;
