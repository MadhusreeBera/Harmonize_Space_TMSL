export const gqlURL = "https://development.harmonize.space/graphql";
