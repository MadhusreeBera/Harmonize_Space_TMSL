import react, { createContext, useEffect, useReducer } from "react";
import Loading from "../../components/Loader/Loading";
import useLoginMutation from "../../hooks/useLoginMutation";
const electron = window.require("electron");
const { ipcRenderer } = electron;
import { authReducer } from "./AuthReducer";

const AuthContext = createContext();
export default AuthContext;

const initialState = {
  loading: true,
  isAuthenticated: false,
  refreshToken: null,
  user: null,
  token: null,
};

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);
  const loginMutation = useLoginMutation();

  useEffect(() => {
    (async () => {
      await ipcRenderer.invoke("getStoreValue", "token").then((token) => {
        loginMutation({
          variables: {
            token,
          },
        }).then(
          async (data) => {
            console.log({ data });
            await ipcRenderer.invoke(
              "storeValue",
              "@token",
              data.data.refreshToken.token
            );
            await ipcRenderer.invoke(
              "storeValue",
              "@refreshToken",
              data.data.refreshToken.refreshToken
            );
            await ipcRenderer.invoke(
              "storeValue",
              "@user",
              data.data.refreshToken.user
            );
            dispatch({
              type: "LOGIN",
              payload: {
                isAuthenticated: true,
                user: data.data.refreshToken.user,
                token: data.data.refreshToken.token,
                refreshToken: data.data.refreshToken.refreshToken,
                loading: false,
              },
            });
          },
          (error) => {
            console.log({ error });
          }
        );
      });
    })();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user: state.user,
        token: state.token,
        isAuthenticated: state.isAuthenticated,
        loading: state.loading,
        refreshToken: state.refreshToken,
        dispatch,
      }}
    >
      {state.loading ? <Loading /> : children}
    </AuthContext.Provider>
  );
};
