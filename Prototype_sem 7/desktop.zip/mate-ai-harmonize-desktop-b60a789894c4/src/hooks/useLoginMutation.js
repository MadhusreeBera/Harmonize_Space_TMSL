import { gql, useMutation } from "@apollo/client";

const loginMutation = gql`
  mutation ($token: String!) {
    refreshToken(token: $token) {
      refreshToken
      token
      user {
        _id
        avatar
        driveLink
        email
        isDriveEnabled
        name
      }
    }
  }
`;

export default () => {
  let doLogin = useMutation(loginMutation)[0];
  return doLogin;
};
