import { gql, useQuery } from "@apollo/client";

const userProfileQuery = gql`
  query profile {
    profile {
      _id
      avatar
      driveLink
      email
      isDriveEnabled
      name
      root
      status
    }
  }
`;

export default () => {
  let profile = useQuery(userProfileQuery);
  return profile;
};
