// require("@electron/remote/main").initialize();
const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const url = require("url");
const dev = require("electron-is-dev");
const os = require("os");
const protocolRegister = require("protocol-registry");
const Store = require("electron-store");
const open = require("open");
const console = require("console");
Store.initRenderer();
const store = new Store();
const gotLock = app.requestSingleInstanceLock();
const fs = require("fs");

const homedir = path.join(os.homedir(), "harmonize-space");

if (!fs.existsSync(homedir)) {
  fs.mkdirSync(homedir);
}

const tempDir = path.join(homedir, ".temp");

if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir);
}

// store.clear();

ipcMain.handle("getStoreValue", (_event, key) => {
  return store.get(key);
});

ipcMain.handle("storeValue", (_event, key, value) => {
  store.set(key, JSON.stringify(value));
});

ipcMain.handle("getOs", () => {
  const platforms = {
    win32: "windows",
    linux: "linux",
    darwin: "macos",
  };
  return platforms[process.platform];
});

let mainWindow;

const startUrl = dev
  ? "http://localhost:3000"
  : url.format({
      pathname: path.join(__dirname, "/../build/index.html"),
      protocol: "file:",
      slashes: true,
    });

const createWindow = () => {
  console.log("createWindow");
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  }
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 800,
    x: 0,
    y: 0,
    center: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
      webSecurity: false,
      nodeIntegrationInWorker: true,
    },
  });
  mainWindow.loadURL(startUrl);
  mainWindow.webContents.openDevTools();
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
};

const getToken = () => {
  return store.get("token");
};
const setToken = (token) => {
  return store.set("token", token);
};

app.on("will-finish-launching", () => {
  console.log("will-finish-launching");
  app.on("open-url", async (event, url) => {
    console.log("open-url", url);
    gotUrl(url);
    await start();
  });
});

const gotUrl = (url) => {
  console.log({ url });
  if (url) {
    url = new URL(url);
    const token = url.searchParams.get("token");
    console.log({ token });
    if (token) setToken(token);
  }
};

app.on("second-instance", async (event, commandLine) => {
  console.log("second instance");
  commandLine = commandLine.filter((arg) => arg.startsWith("harmonize://"));
  if (commandLine.length > 0) {
    gotUrl(commandLine[0]);
  }
  await start();
});

if (!app.isDefaultProtocolClient("harmonize")) {
  console.log("Registering harmonize protocol");
  if (process.defaultApp) {
    console.log({ p: process.argv });
    if (process.argv.length >= 2) {
      app.setAsDefaultProtocolClient("harmonize", process.execPath, [
        path.resolve(process.argv[1]),
      ]);
    }
  } else {
    console.log("Not default app");
    app.setAsDefaultProtocolClient("harmonize");
  }
}

console.log(`"${process.execPath}" "${path.resolve(process.argv[1])}" $_URL_`);

if (dev) {
  console.log("dev");
  protocolRegister
    .register({
      protocol: "harmonize",
      command: `"${process.execPath}" "${path.resolve(
        process.argv[1]
      )}" $_URL_`,
      override: true,
      script: true,
      terminal: dev,
    })
    .then((res) => console.log({ res }))
    .catch((err) => console.error({ err }));
}

const openLogin = async () => {
  await open(
    "https://development.harmonize.space/auth/googleAuth?redirectUrl=harmonize://harmonize.space/auth"
  );
};
const start = async () => {
  console.log("start 1");
  if (!gotLock) {
    console.log("start 1.1");
    return app.quit();
  }
  if (!getToken()) {
    console.log("start 1.2");
    return await openLogin();
  }
  console.log("start 2");
  createWindow();
  app.on("activate", function () {
    console.log("activate");
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
};
app.whenReady().then(start);

app.on("window-all-closed", app.quit);
