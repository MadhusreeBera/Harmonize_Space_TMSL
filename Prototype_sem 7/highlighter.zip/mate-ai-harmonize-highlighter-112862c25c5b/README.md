## Harmonize-Highlighter
This is a chrome extension that lets you highlight important text on any web page.

## Technologies
1. (Vanilla) JavaScript
2. Google API

## Features
1. Highlight any text and hit Ctrl+M to save it automatically
2. User can clear the stored highlights for any URL with one simple command, Ctrl+Shift+U

## How It works
1. Clone the repository from Bit Bucket
2. navigate to `chrome://extensions`
3. Enable developers mode.
3. Click the load unpacked option and select your folder where you cloned this repository.
4. Save the changes, in no time you will be seeing the extension enabled.
5. Click on the extension icon, enjoy your notes.
