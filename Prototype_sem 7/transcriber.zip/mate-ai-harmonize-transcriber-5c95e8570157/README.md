# For Audio Video :

- Rename zappa_settings_AV.json to zappa_settings.json
- virtualenv venv
- pip install -r requirements.txt
- go to venv/Lib/site-packages/moviepy/
- go to video/fx/all/__init__.py add `and name != '__pycache__'`
- go to audio/fx/all/__init__.py add `and name != '__pycache__'`
- download ffmpeg x86_64 to bin/
- zappa update

# For Docs :

- Rename zappa_settings_docs.json to zappa_settings.json
- virtualenv venv
- pip install -r requirements.txt
- go to venv/Lib/site-packages/textract/
- copy venv/Scripts/pdf2txt.py to venv/Lib/site-packages/
- update venv/Lib/site-packages/textract/parser/pdf_parser.py

```py

from pathlib import Path

BASE_DIR=Path(__file__).resolve().parent.parent.parent

def extract_pdfminer(self, filename, **kwargs):
    """Extract text from pdfs using pdfminer."""
    #Nested try/except loops? Not great
    #Try the normal pdf2txt, if that fails try the python3
    # pdf2txt, if that fails try the python2 pdf2txt
    pdf2txt_path = find_executable('pdf2txt.py')
    try:
        stdout, _ = self.run(['python', os.path.join(BASE_DIR, 'pdf2txt.py'), filename])
    except OSError:
        try:
            stdout, _ = self.run(['python3',pdf2txt_path, filename])
        except ShellError:
            stdout, _ = self.run(['python2',pdf2txt_path, filename])
    return stdout

```

- zappa update

# For Image :

- Rename zappa_settings_image.json to zappa_settings.json
- virtualenv venv
- Rename requirements.image.txt to requirements.txt
- pip install -r requirements.txt
- zappa update
- Layers : Tessearact
- Arns : From https://github.com/keithrozario/Klayers/blob/master/deployments/python3.8/arns/ap-south-1.csv Pillow, opencv-python-headless, libgthread-so
- Layer order : Pillow, Tessearact, libgthread-so, opencv-python-headless
- While regenerating requirements.txt, remove Pillow, opencv-python