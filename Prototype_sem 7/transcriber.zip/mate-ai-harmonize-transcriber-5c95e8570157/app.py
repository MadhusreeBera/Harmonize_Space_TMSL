from flask import Flask, request, redirect
from flask_cors import CORS
import os
import traceback
from uuid import uuid4

from trans.config import MEDIA_ROOT, IS_LAMBDA, FFMPEG_ROOT
if IS_LAMBDA:
    os.environ["IMAGEIO_FFMPEG_EXE"] = FFMPEG_ROOT

from trans.extract import get_Extractor
from trans.clear import clear
import requests

app = Flask(__name__)
CORS(app)


@app.route("/", methods=["GET", "POST", "PUT"])
def index():
    try:
        if request.method == "GET":

            return {
                "status":"Running"
            }
        if request.method == "PUT":

            if "file" not in request.files:
                raise Exception("No file uploaded")

            file = request.files["file"]
            if not file or file.filename == "":
                raise Exception("No file uploaded")
            
            path = os.path.join(MEDIA_ROOT, str(uuid4())+file.filename)

            extractor = get_Extractor(path)
            if not callable(extractor):
                return redirect(extractor.get("redirect"), code=307)

            file.save(path)

            text = extractor(path)
            clear()

            return {'file': path,"text": text }
        if request.method == "POST":
        
            content = request.get_json(silent=True)
            url=content.get("url", None)
            name=content.get("name", None)

            if not url:
                raise Exception("Url not provided")
            if not name:
                raise Exception("File name not provided")
            
            path = os.path.join(MEDIA_ROOT, str(uuid4())+str(name))

            extractor = get_Extractor(path)
            
            if not callable(extractor):
                return redirect(extractor.get("redirect"), code=307)

            res = requests.get(url, allow_redirects=True)

            file=open(path, 'wb')
            file.write(res.content)
            file.close()

            text = extractor(path)
            clear()

            return {'file': path,"text": text }
    except Exception as err:
        print(err)
        traceback.print_exc()
        clear()
        return {'error': str(err)}


if __name__ == "__main__":
    app.run(debug=True, threaded=True)