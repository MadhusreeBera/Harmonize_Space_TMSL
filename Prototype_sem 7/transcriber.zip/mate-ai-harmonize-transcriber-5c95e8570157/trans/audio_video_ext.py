import os
import math

import asyncio
from uuid import uuid4

from .config import BASE_URL, MEDIA_ROOT, IS_LAMBDA

Redirect_Path= BASE_URL + "/audiovideo"

def extract_text_from_video(path):
    return extract_text_from_audio(path)

def extract_text_from_audio(path):
    
    import speech_recognition as sr
    import moviepy.editor as mp

    clip=mp.AudioFileClip(path)
    duration = clip.duration
    if duration==0 :
        return ""
    cuts=list(range(0,math.ceil(duration),50))
    clip.close()
    del clip
    num_of_cuts=len(cuts)
    chunks=[None]*num_of_cuts
    def get_text(start,end,ind):
        clip=mp.AudioFileClip(path)
        if start>=end :
            chunks[ind]=""
            return
        short_clip=clip.subclip(start, end)
        audio_path=os.path.join(MEDIA_ROOT, "cut" + str(uuid4()) + ".wav" )
        short_clip.write_audiofile(audio_path)
        try:
            r = sr.Recognizer()
            audio = sr.AudioFile(audio_path)
            with audio as source:
                r.adjust_for_ambient_noise(source)  
                audio_file = r.record(source)
            chunks[ind]=r.recognize_google(audio_file)
        except:
            chunks[ind]=""
        if not IS_LAMBDA:
            os.remove(audio_path)
        short_clip.close()
        clip.close()
        return
    def get_thread(i):
        return asyncio.to_thread(lambda:get_text(cuts[i]-1*(cuts[i]!=0), duration if (i+1)==num_of_cuts else cuts[i+1],i))
    async def main():
        await asyncio.gather(*[get_thread(i) for i in range(num_of_cuts)])
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    asyncio.run(main())
    loop.close()
    return '\n'.join(map(str,chunks))

