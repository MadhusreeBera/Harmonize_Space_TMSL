import os
import traceback

from trans.config import IS_LAMBDA, MEDIA_ROOT

def clear():
    if IS_LAMBDA:
        return
    try:
        for f in os.listdir(MEDIA_ROOT):
            os.remove(os.path.join(MEDIA_ROOT, f))
        return
    except Exception as e:
        print(e)
        traceback.print_exc()
