from pathlib import Path
import os

BASE_DIR=BASE_DIR = Path(__file__).resolve().parent.parent
IS_LAMBDA= os.environ.get("AWS_EXECUTION_ENV") is not None
MEDIA_ROOT = os.path.join(BASE_DIR, "media") if not IS_LAMBDA else "/tmp"
FFMPEG_ROOT = os.path.join(BASE_DIR, "bin", "ffmpeg")
BASE_URL= "https://trans.harmonize.space"

Has_Audio_Video = False
Has_textract = True
Has_Image = False


Image_Redirect_Path = BASE_URL + "/image"
Audio_Video_Redirect_Path = BASE_URL + "/audiovideo"
Docs_Redirect_Path = BASE_URL + "/docs"