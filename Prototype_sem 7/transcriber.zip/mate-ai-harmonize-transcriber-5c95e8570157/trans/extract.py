import mimetypes

from .config import *
from .audio_video_ext import extract_text_from_video, extract_text_from_audio
from .textract_ext import extract_text_using_textract, extract_text_from_pdf
from .text_ext import read_text
from .image_ext import extract_text_from_image, extract_text_from_gif

def includes(str,sub):
    try:
        str.index(sub)
        return True
    except:
        return False
def is_office_file(mime):
    return includes(mime,"officedocument") or includes(mime,"msword") or includes(mime,"ms-excel") or includes(mime,"ms-powerpoint")
def get_known_mime(path):
    docx_mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    pptx_mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    ppt_mime = "application/vnd.ms-powerpoint"
    xlsx_mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    xls_mime = "application/vnd.ms-excel"

    if(path.endswith(".csv")):
        return "vdn/officedocument.spreadsheetml.sheet"
    if(path.endswith(".doc")):
        return "application/msword"
    if(path.endswith(".docx")):
        return docx_mime
    if(path.endswith(".pptx")):
        return pptx_mime
    if(path.endswith(".ppt")):
        return ppt_mime
    if(path.endswith(".xlsx")):
        return xlsx_mime
    if(path.endswith(".xls")):
        return xls_mime
    return None

def mime_of(path):
    mime=mimetypes.guess_type(path)
    if len(mime)==0 :
        mime=get_known_mime(path)
        if mime:
            return mime
        raise Exception("Could not detect file type")
    else:
        mime=mime[0]
    if not mime:
        mime=get_known_mime(path)
        if mime:
            return mime
        raise Exception("Could not detect file type")
    return mime
def get_Extractor(path):
    mime=mime_of(path)

    if mime=="image/gif" and Has_Image:
        return extract_text_from_gif
    elif mime.startswith('image') and Has_Image :
        return extract_text_from_image
    elif mime.startswith('video') and Has_Audio_Video :
        return extract_text_from_video
    elif mime.startswith('audio') and Has_Audio_Video :
        return extract_text_from_audio
    elif is_office_file(mime) and Has_textract :
        return extract_text_using_textract
    elif mime.endswith('/pdf') and Has_textract :
        return extract_text_from_pdf
    elif mime.startswith('text') or mime=='application/javascript' or mime=='application/json' :
        return read_text
    else:
        raise Exception("File type not supported")
