from PIL import Image, ImageEnhance
import PIL.ImageOps
from sys import platform
import asyncio

from trans.config import IS_LAMBDA

def get_tesseract():
    return r'tesseract' if platform == "linux" or platform == "linux2" else r'C:/Program Files/Tesseract-OCR/tesseract.exe' 

def extract_text_from_gif(path):
    import pytesseract
    if not IS_LAMBDA:
        pytesseract.pytesseract.tesseract_cmd = get_tesseract()
    image = Image.open(path)
    chunks=[None]*image.n_frames
    def get_text(frame):
        img= image.copy()
        img.seek(frame)
        imgrgb = img.convert('RGB')
        
        imgrgb = PIL.ImageOps.invert(imgrgb)
        
        enhancer = ImageEnhance.Brightness(imgrgb)
        imgrgb = enhancer.enhance(1.8)
        
        enhancer = ImageEnhance.Contrast(imgrgb)
        imgrgb = enhancer.enhance(4.0)

        imgrgb = imgrgb.convert('1')
        chunks[frame] = pytesseract.image_to_string(imgrgb)
        img.close()
    def get_thread(i):
        return asyncio.to_thread(lambda:get_text(i))
    async def main():
        await asyncio.gather(*[get_thread(frame) for frame in range(0,image.n_frames)])
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    asyncio.run(main())
    loop.close()
    image.close()
    return '\n'.join(map(str,chunks))


def extract_text_from_image(path):
    import cv2
    import pytesseract
    if not IS_LAMBDA:
        pytesseract.pytesseract.tesseract_cmd = get_tesseract()
    image = cv2.imread(path)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    threshold_img = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    custom_config = r'--oem 3 --psm 6'
    text = pytesseract.image_to_string(threshold_img, config=custom_config, lang="eng")
    return text
