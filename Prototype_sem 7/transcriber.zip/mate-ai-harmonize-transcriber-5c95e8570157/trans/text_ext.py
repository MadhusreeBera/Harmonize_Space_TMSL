def read_text(path):
    lines=[]
    with open(path) as f:
        lines = f.readlines()
    return '\n'.join(lines)
