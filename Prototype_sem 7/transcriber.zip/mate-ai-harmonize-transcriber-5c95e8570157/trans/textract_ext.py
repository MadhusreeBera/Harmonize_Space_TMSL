def extract_text_from_pdf(path):
    import PyPDF2 
    pdfFileObj = open(path, 'rb') 
    pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
    text=""
    for i in range(pdfReader.numPages):
        pageObj = pdfReader.getPage(i)
        text += str(pageObj.extractText())
    pdfFileObj.close() 
    return text

def extract_text_using_textract(path):
    import textract
    if path.endswith("pdf") :
        return extract_text_from_pdf(path)
    return str(textract.process(path))
